
import React, { useState } from 'react';
import { Upload, FileDown, TrendingUp, BarChart3, ChevronRight, Info, CheckCircle2, Sparkles, FileSpreadsheet, Settings as SettingsIcon } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ForecastResult } from '../types';
import { generateSalesForecast } from '../services/geminiService';

interface SalesForecastingProps {
  onForecastUpdate: (result: ForecastResult) => void;
  currentResult: ForecastResult | null;
}

const SalesForecasting: React.FC<SalesForecastingProps> = ({ onForecastUpdate, currentResult }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [localResult, setLocalResult] = useState<ForecastResult | null>(currentResult);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    const reader = new FileReader();
    reader.onload = async (event) => {
      const csvContent = event.target?.result as string;
      try {
        const analysis = await generateSalesForecast(csvContent);
        setLocalResult(analysis);
        onForecastUpdate(analysis);
      } catch (error: any) {
        console.error("Detailed Error:", error);
        
        if (error.message.includes("API_KEY_MISSING") || error.message.includes("API key not valid")) {
          alert("AUTHENTICATION ERROR:\n\nYour API key is missing or invalid. Please go to the 'Settings' tab in the sidebar and paste your Gemini API Key manually.");
        } else {
          alert(`Analysis Failed: ${error.message}`);
        }
      } finally {
        setIsProcessing(false);
      }
    };
    reader.readAsText(file);
  };

  const downloadSampleCSV = () => {
    const csvContent = "Month,Sales\nJanuary,45000\nFebruary,48000\nMarch,52000\nApril,49000\nMay,55000\nJune,60000\nJuly,62000\nAugust,58000\nSeptember,63000\nOctober,68000\nNovember,75000\nDecember,95000";
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = "intellisales_template.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Data Processor</h2>
          <p className="text-slate-500">Upload your sales history to generate AI predictions.</p>
        </div>
        
        <div className="flex items-center gap-3">
          <button 
            onClick={downloadSampleCSV}
            className="flex items-center gap-2 px-4 py-3 bg-slate-100 text-slate-600 rounded-xl font-semibold hover:bg-slate-200 transition-all border border-slate-200"
          >
            <FileSpreadsheet size={18} />
            <span className="hidden sm:inline">Get Template</span>
          </button>

          <label className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 cursor-pointer transition-all shadow-lg shadow-indigo-100">
            <Upload size={18} />
            <span>Upload CSV</span>
            <input type="file" accept=".csv" className="hidden" onChange={handleFileUpload} />
          </label>
        </div>
      </div>

      {isProcessing ? (
        <div className="bg-white rounded-[2rem] p-20 text-center shadow-sm border border-slate-100">
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4"></div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">Analyzing Data Patterns</h3>
            <p className="text-slate-500">Modelling sales data with Gemini 3...</p>
          </div>
        </div>
      ) : localResult ? (
        <div className="bg-indigo-50 border border-indigo-100 rounded-[2rem] p-10 flex flex-col items-center text-center">
          <CheckCircle2 size={48} className="text-indigo-600 mb-4" />
          <h3 className="text-2xl font-bold text-slate-900 mb-2">Analysis Complete</h3>
          <p className="text-slate-600 mb-8">Your intelligence dashboard is now fully synced with your CSV data.</p>
        </div>
      ) : (
        <div className="bg-white border-2 border-dashed border-slate-200 rounded-[2rem] p-20 text-center">
          <BarChart3 size={48} className="mx-auto mb-4 text-slate-300" />
          <h3 className="text-xl font-bold text-slate-900 mb-2">Ready to Start</h3>
          <p className="text-slate-500 mb-8">Upload a CSV to generate your 6-month sales forecast.</p>
          <div className="flex flex-col items-center gap-4">
            <button onClick={downloadSampleCSV} className="text-indigo-600 font-bold hover:underline flex items-center gap-1">
              <FileSpreadsheet size={14} /> Download working CSV template
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default SalesForecasting;

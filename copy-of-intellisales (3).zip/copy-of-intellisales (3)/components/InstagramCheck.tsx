
import React, { useState } from 'react';
import { Search, Instagram, CheckCircle, XCircle, ShieldAlert } from 'lucide-react';
import { checkInstagramId } from '../services/geminiService';

interface InstagramCheckProps {
  onComplete: (summary: string) => void;
}

const InstagramCheck: React.FC<InstagramCheckProps> = ({ onComplete }) => {
  const [handle, setHandle] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ result: string; reason: string } | null>(null);

  const handleCheck = async () => {
    if (!handle) return;
    setLoading(true);
    try {
      const audit = await checkInstagramId(handle);
      setResult(audit);
      onComplete(`Social Audit for @${handle}: ${audit.result}`);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Social Audit Tool</h2>
        <p className="text-slate-500">Verify influencer authenticity or profile validity using AI heuristics.</p>
      </div>

      <div className="max-w-2xl mx-auto space-y-8">
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
          <div className="flex items-center gap-4 p-2 bg-slate-50 border border-slate-200 rounded-2xl">
            <div className="pl-4 text-slate-400">
              <Instagram size={20} />
            </div>
            <input 
              type="text" 
              placeholder="Enter Instagram Handle (e.g. zuck)" 
              className="flex-1 bg-transparent py-3 text-slate-900 placeholder:text-slate-400 outline-none font-medium"
              value={handle}
              onChange={(e) => setHandle(e.target.value.replace('@', ''))}
            />
            <button 
              onClick={handleCheck}
              disabled={loading || !handle}
              className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all disabled:opacity-50"
            >
              {loading ? 'Analyzing...' : 'Audit Profile'}
            </button>
          </div>
          <p className="mt-4 text-xs text-slate-400 text-center">
            Our AI analyzes naming patterns, engagement probability, and profile consistency.
          </p>
        </div>

        {result && (
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm animate-in zoom-in duration-300">
            <div className="flex flex-col items-center text-center">
              <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-6 ${
                result.result === 'Real' ? 'bg-emerald-100 text-emerald-600' : 'bg-red-100 text-red-600'
              }`}>
                {result.result === 'Real' ? <CheckCircle size={40} /> : <ShieldAlert size={40} />}
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-2">
                This Profile appears <span className={result.result === 'Real' ? 'text-emerald-600' : 'text-red-600'}>{result.result}</span>
              </h3>
              <p className="text-slate-600 max-w-lg leading-relaxed">
                {result.reason}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default InstagramCheck;


import React from 'react';
import { 
  TrendingUp, 
  ArrowUpRight, 
  DollarSign, 
  Target, 
  ChevronRight, 
  BarChart3, 
  Sparkles,
  Layers,
  Calendar
} from 'lucide-react';
import { ForecastResult } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface UserDashboardProps {
  forecast: ForecastResult | null;
  onUploadRequest: () => void;
}

const UserDashboard: React.FC<UserDashboardProps> = ({ forecast, onUploadRequest }) => {
  if (!forecast) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-8 animate-in fade-in duration-700">
        <div className="max-w-2xl w-full bg-white rounded-[2rem] p-12 text-center shadow-xl shadow-slate-200 border border-slate-100">
          <div className="w-24 h-24 bg-indigo-50 rounded-3xl flex items-center justify-center mx-auto mb-8 text-indigo-600">
            <BarChart3 size={48} />
          </div>
          <h1 className="text-4xl font-bold text-slate-900 mb-4 tracking-tight">Generate Your Dashboard</h1>
          <p className="text-slate-500 text-lg mb-10 leading-relaxed">
            Upload your sales history CSV to unlock a personalized, AI-driven dashboard featuring future projections, demand analysis, and growth strategies.
          </p>
          <button 
            onClick={onUploadRequest}
            className="px-10 py-5 bg-indigo-600 text-white rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 flex items-center gap-3 mx-auto"
          >
            <Layers size={22} />
            Start Sales Analysis
          </button>
        </div>
      </div>
    );
  }

  // Calculate Metrics
  const totalHistRevenue = forecast.historicalData.reduce((sum, item) => sum + item.value, 0);
  const avgMonthly = totalHistRevenue / forecast.historicalData.length;
  const projectedPeak = Math.max(...forecast.forecastData.map(d => d.value));
  const combinedData = [...forecast.historicalData, ...forecast.forecastData];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Sales Intelligence Dashboard</h1>
          <p className="text-slate-500 mt-1">Real-time analysis based on your uploaded sales data.</p>
        </div>
        <div className="hidden md:flex items-center gap-2 text-xs font-semibold text-indigo-600 bg-indigo-50 px-4 py-2 rounded-full border border-indigo-100">
          <Sparkles size={14} />
          AI ANALYTICS ACTIVE
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <KPICard 
          label="Historical Revenue" 
          value={`₹${totalHistRevenue.toLocaleString()}`} 
          trend="+12.4%" 
          icon={<DollarSign size={20} />} 
          color="indigo" 
        />
        <KPICard 
          label="Monthly Average" 
          value={`₹${Math.round(avgMonthly).toLocaleString()}`} 
          trend="Stable" 
          icon={<Calendar size={20} />} 
          color="emerald" 
        />
        <KPICard 
          label="Projected Peak" 
          value={`₹${projectedPeak.toLocaleString()}`} 
          trend="Forecasted" 
          icon={<TrendingUp size={20} />} 
          color="amber" 
        />
        <KPICard 
          label="Growth Potential" 
          value="High" 
          trend="8.2x" 
          icon={<Target size={20} />} 
          color="rose" 
        />
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white rounded-[2rem] p-8 shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h3 className="text-xl font-bold text-slate-900">Revenue Performance & Projections</h3>
              <p className="text-sm text-slate-400">Integrated historical and future sales timeline</p>
            </div>
            <div className="flex gap-4">
              <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
                <span className="w-3 h-3 bg-indigo-600 rounded-full"></span> Historical
              </div>
              <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
                <span className="w-3 h-3 bg-indigo-300 rounded-full"></span> Forecasted
              </div>
            </div>
          </div>
          <div className="h-[400px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={combinedData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="period" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fill: '#94a3b8', fontSize: 12}} 
                  dy={15}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fill: '#94a3b8', fontSize: 12}} 
                  tickFormatter={(val) => `₹${val/1000}k`}
                />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)' }}
                  formatter={(value: number) => [`₹${value.toLocaleString()}`, 'Revenue']}
                />
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#4f46e5" 
                  strokeWidth={4} 
                  fillOpacity={1} 
                  fill="url(#colorRevenue)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* AI Strategy & Insights */}
        <div className="space-y-8">
          <div className="bg-slate-900 rounded-[2rem] p-8 text-white shadow-xl">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center">
                <Sparkles size={20} className="text-indigo-400" />
              </div>
              <h3 className="text-xl font-bold">Strategic Insights</h3>
            </div>
            <div className="space-y-4">
              {forecast.insights.slice(0, 4).map((insight, idx) => (
                <div key={idx} className="flex gap-3 group">
                  <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0"></div>
                  <p className="text-sm text-slate-300 leading-relaxed group-hover:text-white transition-colors">
                    {insight}
                  </p>
                </div>
              ))}
            </div>
            <button className="w-full mt-8 py-4 bg-indigo-600 hover:bg-indigo-700 rounded-2xl text-sm font-bold transition-all flex items-center justify-center gap-2">
              Generate Detailed Report
              <ChevronRight size={16} />
            </button>
          </div>

          <div className="bg-white rounded-[2rem] p-8 shadow-sm border border-slate-100">
            <h3 className="font-bold text-slate-900 mb-6 flex items-center gap-2">
              <BarChart3 size={18} className="text-indigo-600" />
              Upcoming Milestones
            </h3>
            <div className="space-y-4">
              {forecast.forecastData.slice(0, 3).map((item, idx) => (
                <div key={idx} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                  <div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{item.period}</p>
                    <p className="font-bold text-slate-900 mt-0.5">₹{item.value.toLocaleString()}</p>
                  </div>
                  <div className="w-10 h-10 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center">
                    <ArrowUpRight size={18} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const KPICard = ({ label, value, trend, icon, color }: any) => {
  const colorMap: any = {
    indigo: 'bg-indigo-50 text-indigo-600',
    emerald: 'bg-emerald-50 text-emerald-600',
    amber: 'bg-amber-50 text-amber-600',
    rose: 'bg-rose-50 text-rose-600',
  };

  return (
    <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100 group hover:border-indigo-200 transition-all">
      <div className="flex justify-between items-start mb-4">
        <div className={`w-12 h-12 ${colorMap[color]} rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110`}>
          {icon}
        </div>
        <span className={`text-xs font-bold px-2 py-1 rounded-full ${colorMap[color]}`}>
          {trend}
        </span>
      </div>
      <div>
        <p className="text-sm font-medium text-slate-400">{label}</p>
        <p className="text-2xl font-bold text-slate-900 mt-1">{value}</p>
      </div>
    </div>
  );
};

export default UserDashboard;

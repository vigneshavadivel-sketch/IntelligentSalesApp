
import React, { useState } from 'react';
import { Shield, Target, Zap, AlertTriangle, Users, ArrowRightLeft } from 'lucide-react';
import { analyzeCompetitor } from '../services/geminiService';
import { CompetitorSWOT } from '../types';

interface CompetitorAnalysisProps {
  onComplete: (summary: string) => void;
}

const CompetitorAnalysis: React.FC<CompetitorAnalysisProps> = ({ onComplete }) => {
  const [myCompany, setMyCompany] = useState('');
  const [competitor, setCompetitor] = useState('');
  const [result, setResult] = useState<CompetitorSWOT | null>(null);
  const [loading, setLoading] = useState(false);

  const runAnalysis = async () => {
    if (!myCompany || !competitor) return;
    setLoading(true);
    try {
      const swot = await analyzeCompetitor(myCompany, competitor);
      setResult(swot);
      onComplete(`Compared ${myCompany} vs ${competitor}`);
    } catch (error) {
      console.error(error);
      alert("Analysis failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Market Intelligence</h2>
        <p className="text-slate-500">Battle-test your strategy against industry rivals.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-3xl p-8 border border-slate-100 shadow-sm h-fit">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center">
              <ArrowRightLeft size={20} />
            </div>
            <h3 className="text-xl font-bold text-slate-900">Comparison Setup</h3>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Your Company</label>
              <input 
                type="text" 
                placeholder="e.g. Acme SaaS" 
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                value={myCompany}
                onChange={(e) => setMyCompany(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Competitor Company</label>
              <input 
                type="text" 
                placeholder="e.g. Globex Corp" 
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                value={competitor}
                onChange={(e) => setCompetitor(e.target.value)}
              />
            </div>

            <button
              onClick={runAnalysis}
              disabled={loading || !myCompany || !competitor}
              className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div> : 'Start Intelligence Sweep'}
            </button>
          </div>
        </div>

        <div className="space-y-6">
          {result ? (
            <div className="space-y-6 animate-in fade-in duration-500">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-emerald-50 p-6 rounded-3xl border border-emerald-100">
                  <div className="flex items-center gap-2 text-emerald-700 font-bold mb-3">
                    <Shield size={18} />
                    <span>Strengths</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-600">
                    {result.strengths.map((s, i) => <li key={i} className="flex gap-2"><span>•</span>{s}</li>)}
                  </ul>
                </div>

                <div className="bg-orange-50 p-6 rounded-3xl border border-orange-100">
                  <div className="flex items-center gap-2 text-orange-700 font-bold mb-3">
                    <Target size={18} />
                    <span>Weaknesses</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-600">
                    {result.weaknesses.map((s, i) => <li key={i} className="flex gap-2"><span>•</span>{s}</li>)}
                  </ul>
                </div>

                <div className="bg-blue-50 p-6 rounded-3xl border border-blue-100">
                  <div className="flex items-center gap-2 text-blue-700 font-bold mb-3">
                    <Zap size={18} />
                    <span>Opportunities</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-600">
                    {result.opportunities.map((s, i) => <li key={i} className="flex gap-2"><span>•</span>{s}</li>)}
                  </ul>
                </div>

                <div className="bg-red-50 p-6 rounded-3xl border border-red-100">
                  <div className="flex items-center gap-2 text-red-700 font-bold mb-3">
                    <AlertTriangle size={18} />
                    <span>Threats</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-600">
                    {result.threats.map((s, i) => <li key={i} className="flex gap-2"><span>•</span>{s}</li>)}
                  </ul>
                </div>
              </div>

              <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                  <Users size={20} className="text-indigo-600" />
                  Key Strategic Differences
                </h3>
                <p className="text-slate-600 text-sm leading-relaxed">
                  {result.differences}
                </p>
              </div>
            </div>
          ) : (
            <div className="h-full min-h-[400px] flex flex-col items-center justify-center bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center text-slate-400">
              <Users size={48} className="mb-4 opacity-20" />
              <p>Enter company names to compare their market standing and strategic advantages.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CompetitorAnalysis;


import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Activity as ActivityIcon, 
  ShieldCheck, 
  TrendingUp, 
  Search,
  Mail,
  Clock,
  ExternalLink
} from 'lucide-react';
import { Activity } from '../types';

const AdminPanel: React.FC = () => {
  const [globalHistory, setGlobalHistory] = useState<Activity[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const rawHistory = localStorage.getItem('intellisales_global_history');
    if (rawHistory) {
      setGlobalHistory(JSON.parse(rawHistory));
    }
  }, []);

  const filteredHistory = globalHistory.filter(act => 
    act.userEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
    act.summary.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const stats = [
    { label: 'Total Users', value: '12', icon: <Users size={20}/>, color: 'indigo' },
    { label: 'AI Operations', value: globalHistory.length.toString(), icon: <ActivityIcon size={20}/>, color: 'emerald' },
    { label: 'Security Score', value: '98%', icon: <ShieldCheck size={20}/>, color: 'blue' },
    { label: 'Growth rate', value: '+14%', icon: <TrendingUp size={20}/>, color: 'amber' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Admin Console</h2>
        <p className="text-slate-500">Global system monitoring and user activity logs.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
            <div className={`w-10 h-10 mb-4 rounded-xl flex items-center justify-center text-white ${
              stat.color === 'indigo' ? 'bg-indigo-600' :
              stat.color === 'emerald' ? 'bg-emerald-600' :
              stat.color === 'blue' ? 'bg-blue-600' : 'bg-amber-600'
            }`}>
              {stat.icon}
            </div>
            <p className="text-sm font-medium text-slate-500">{stat.label}</p>
            <p className="text-2xl font-bold text-slate-900 mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600">
              <ActivityIcon size={20} />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900">Audit Logs</h3>
              <p className="text-sm text-slate-500">Real-time platform usage tracking</p>
            </div>
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-2.5 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Search user or activity..." 
              className="pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none w-full md:w-64"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/50 text-slate-400 text-xs font-bold uppercase tracking-wider">
                <th className="px-8 py-4">User</th>
                <th className="px-8 py-4">Module</th>
                <th className="px-8 py-4">Action Summary</th>
                <th className="px-8 py-4">Timestamp</th>
                <th className="px-8 py-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredHistory.length > 0 ? filteredHistory.map((act) => (
                <tr key={act.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center text-xs font-bold">
                        {act.userEmail[0].toUpperCase()}
                      </div>
                      <span className="text-sm font-medium text-slate-700">{act.userEmail}</span>
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-full text-xs font-semibold capitalize">
                      {act.type}
                    </span>
                  </td>
                  <td className="px-8 py-5">
                    <p className="text-sm text-slate-600 max-w-xs truncate">{act.summary}</p>
                  </td>
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-2 text-slate-400">
                      <Clock size={14} />
                      <span className="text-xs">{new Date(act.timestamp).toLocaleString()}</span>
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                      <span className="text-xs font-medium text-emerald-600">Verified</span>
                    </div>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={5} className="px-8 py-12 text-center text-slate-400">
                    No activity records found matching your criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;


import React from 'react';
import { 
  LayoutDashboard, 
  TrendingUp, 
  Package, 
  Users, 
  Instagram, 
  MessageSquare, 
  LogOut,
  ShieldCheck,
  Settings as SettingsIcon
} from 'lucide-react';
import { View } from '../types';

interface SidebarProps {
  currentView: View;
  setView: (view: View) => void;
  onLogout: () => void;
  userRole?: 'admin' | 'user';
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView, onLogout, userRole }) => {
  const adminItems = [
    { id: 'admin', label: 'Admin Panel', icon: ShieldCheck },
  ];

  const userItems = [
    { id: 'dashboard', label: 'Overview', icon: LayoutDashboard },
    { id: 'sales', label: 'Sales Forecast', icon: TrendingUp },
    { id: 'product', label: 'Product Lab', icon: Package },
    { id: 'competitor', label: 'Market Intelligence', icon: Users },
    { id: 'instagram', label: 'Social Audit', icon: Instagram },
    { id: 'chat', label: 'AI Consultant', icon: MessageSquare },
  ];

  const menuItems = userRole === 'admin' ? [...adminItems, ...userItems] : userItems;

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col h-full hidden md:flex">
      <div className="p-6">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-100">
            <TrendingUp size={24} />
          </div>
          <span className="text-xl font-bold text-slate-900 tracking-tight">IntelliSales</span>
        </div>

        <nav className="space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setView(item.id as View)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  isActive 
                    ? 'bg-indigo-50 text-indigo-700 font-semibold' 
                    : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <Icon size={20} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      <div className="mt-auto p-6 space-y-2 border-t border-slate-100">
        <button 
          onClick={() => setView('settings')}
          className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
            currentView === 'settings' 
              ? 'bg-slate-100 text-slate-900 font-semibold' 
              : 'text-slate-500 hover:bg-slate-50'
          }`}
        >
          <SettingsIcon size={20} />
          <span>Settings</span>
        </button>
        <button 
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-500 hover:bg-red-50 transition-all font-medium"
        >
          <LogOut size={20} />
          <span>Sign Out</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;

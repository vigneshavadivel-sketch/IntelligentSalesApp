
import React, { useState, useEffect } from 'react';
import { Key, Save, Trash2, CheckCircle2, AlertCircle, Info, ExternalLink, ShieldCheck } from 'lucide-react';
import { testApiKey } from '../services/geminiService';

const Settings: React.FC = () => {
  const [apiKey, setApiKey] = useState('');
  const [isTesting, setIsTesting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');

  useEffect(() => {
    const saved = localStorage.getItem('intellisales_api_key');
    if (saved) setApiKey(saved);
  }, []);

  const handleSave = async () => {
    const trimmedKey = apiKey.trim();
    if (!trimmedKey) {
      alert("Please enter a key first.");
      return;
    }
    
    setIsTesting(true);
    setStatus('idle');
    setErrorMessage('');
    
    const result = await testApiKey(trimmedKey);
    
    if (result.success) {
      localStorage.setItem('intellisales_api_key', trimmedKey);
      setStatus('success');
    } else {
      setStatus('error');
      setErrorMessage(result.error || 'The API key was rejected by Google. Double check the characters.');
    }
    setIsTesting(false);
  };

  const handleClear = () => {
    if (window.confirm("Are you sure you want to remove the API key?")) {
      localStorage.removeItem('intellisales_api_key');
      setApiKey('');
      setStatus('idle');
      setErrorMessage('');
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-slate-900 tracking-tight">System Configuration</h2>
          <p className="text-slate-500 mt-1">Configure your AI engine and API credentials.</p>
        </div>
        <div className="p-3 bg-white rounded-2xl border border-slate-100 shadow-sm">
          <ShieldCheck className="text-indigo-600" size={24} />
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] p-8 md:p-12 border border-slate-100 shadow-sm space-y-10">
        <div className="flex items-start gap-5 p-6 bg-indigo-50/50 rounded-3xl border border-indigo-100">
          <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shrink-0 shadow-sm border border-indigo-50">
            <Info className="text-indigo-600" size={24} />
          </div>
          <div className="space-y-2">
            <h4 className="font-bold text-indigo-900">Important: API Authentication</h4>
            <p className="text-sm text-indigo-700/80 leading-relaxed">
              Gemini API keys are case-sensitive and must be copied exactly. 
              The error you saw earlier might be due to regional restrictions or missing billing info on your Google project.
            </p>
            <a 
              href="https://aistudio.google.com/app/apikey" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-sm font-bold text-indigo-600 hover:text-indigo-700 hover:underline mt-2 transition-all"
            >
              Get a fresh key from Google AI Studio <ExternalLink size={14} />
            </a>
          </div>
        </div>

        <div className="space-y-5">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-[0.2em]">Google Gemini Key</label>
            {apiKey && <span className="text-[10px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full">Encrypted in LocalStorage</span>}
          </div>
          
          <div className="relative group">
            <input 
              type="password" 
              placeholder="Paste your key here (e.g. AIzaSy...)" 
              className={`w-full pl-14 pr-4 py-5 bg-slate-50/50 border rounded-3xl focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all font-mono text-sm ${
                status === 'success' ? 'border-emerald-200' : status === 'error' ? 'border-red-200' : 'border-slate-200 group-hover:border-slate-300'
              }`}
              value={apiKey}
              onChange={(e) => {
                setApiKey(e.target.value);
                if (status !== 'idle') setStatus('idle');
              }}
            />
            <div className={`absolute left-5 top-5 transition-colors ${status === 'success' ? 'text-emerald-500' : status === 'error' ? 'text-red-500' : 'text-slate-400'}`}>
              <Key size={20} />
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 pt-2">
            <button
              onClick={handleSave}
              disabled={isTesting || !apiKey}
              className="flex-[3] py-5 bg-slate-900 text-white rounded-3xl font-bold hover:bg-black disabled:opacity-50 transition-all flex items-center justify-center gap-3 shadow-xl shadow-slate-200 active:scale-[0.98]"
            >
              {isTesting ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div> : <Save size={20} />}
              Verify Connection
            </button>
            <button
              onClick={handleClear}
              className="flex-1 px-6 py-5 bg-white text-slate-400 border border-slate-200 rounded-3xl font-bold hover:bg-red-50 hover:text-red-600 hover:border-red-100 transition-all flex items-center justify-center gap-2"
              title="Remove Key"
            >
              <Trash2 size={20} />
              <span className="sm:hidden">Remove Key</span>
            </button>
          </div>
        </div>

        {status === 'success' && (
          <div className="flex items-start gap-4 p-5 bg-emerald-50 text-emerald-700 rounded-3xl border border-emerald-100 animate-in zoom-in duration-300">
            <div className="bg-white p-2 rounded-xl shadow-sm border border-emerald-50">
              <CheckCircle2 size={20} />
            </div>
            <div>
              <p className="font-bold">Authentication Verified</p>
              <p className="text-sm opacity-80">Your key is active and ready for sales forecasting.</p>
            </div>
          </div>
        )}

        {status === 'error' && (
          <div className="flex items-start gap-4 p-5 bg-red-50 text-red-700 rounded-3xl border border-red-100 animate-in zoom-in duration-300">
            <div className="bg-white p-2 rounded-xl shadow-sm border border-red-50">
              <AlertCircle size={20} />
            </div>
            <div>
              <p className="font-bold">Google Rejected This Key</p>
              <p className="text-sm opacity-90 leading-relaxed font-mono mt-1 text-red-600 bg-white/50 p-2 rounded-lg border border-red-100 break-all">
                {errorMessage}
              </p>
            </div>
          </div>
        )}
      </div>

      <div className="text-center">
        <p className="text-xs text-slate-400">
          All processing is done directly between your browser and Google. <br/>Your API key is never sent to our servers.
        </p>
      </div>
    </div>
  );
};

export default Settings;


import React, { useState } from 'react';
import { Camera, Image as ImageIcon, Sparkles, IndianRupee, Activity, TrendingUp } from 'lucide-react';
import { analyzeProductImage } from '../services/geminiService';
import { ProductAnalysisResult } from '../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface ProductAnalysisProps {
  onComplete: (summary: string) => void;
}

const ProductAnalysis: React.FC<ProductAnalysisProps> = ({ onComplete }) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [result, setResult] = useState<ProductAnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const runAnalysis = async () => {
    if (!selectedImage) return;
    setLoading(true);
    try {
      const base64 = selectedImage.split(',')[1];
      const analysis = await analyzeProductImage(base64);
      setResult(analysis);
      onComplete(`Analyzed product: ${analysis.name}`);
    } catch (error) {
      console.error(error);
      alert("Analysis failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Product Intelligence Lab</h2>
          <p className="text-slate-500">Analyze products with AI for the Indian market.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-8 border border-slate-100 shadow-sm">
            <div className="aspect-video w-full bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200 overflow-hidden relative group">
              {selectedImage ? (
                <img src={selectedImage} alt="Preview" className="w-full h-full object-contain" />
              ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400">
                  <ImageIcon size={48} className="mb-4" />
                  <p>Upload a product image</p>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4 mt-6">
              <label className="flex items-center justify-center gap-2 py-4 bg-slate-100 text-slate-700 rounded-xl font-semibold hover:bg-slate-200 cursor-pointer transition-all">
                <Camera size={18} />
                <span>Camera</span>
                <input type="file" capture="environment" accept="image/*" className="hidden" onChange={handleImageChange} />
              </label>
              <label className="flex items-center justify-center gap-2 py-4 bg-slate-100 text-slate-700 rounded-xl font-semibold hover:bg-slate-200 cursor-pointer transition-all">
                <ImageIcon size={18} />
                <span>Gallery</span>
                <input type="file" accept="image/*" className="hidden" onChange={handleImageChange} />
              </label>
            </div>

            {selectedImage && (
              <button
                onClick={runAnalysis}
                disabled={loading}
                className="w-full mt-6 py-4 bg-indigo-600 text-white rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all disabled:opacity-50"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <>
                    <Sparkles size={18} />
                    Analyze for India
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        <div className="space-y-6">
          {result ? (
            <div className="bg-white rounded-3xl p-8 border border-slate-100 shadow-sm animate-in zoom-in duration-300">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center">
                  <Sparkles size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900">{result.name}</h3>
                  <p className="text-slate-500 text-sm">Market Analysis (INR)</p>
                </div>
              </div>

              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
                    <div className="flex items-center gap-2 text-emerald-600 font-bold mb-1">
                      <IndianRupee size={16} />
                      <span>Est. Cost</span>
                    </div>
                    <p className="text-slate-700 text-lg font-bold">{result.estimatedCost}</p>
                  </div>
                  <div className="p-4 bg-indigo-50 rounded-2xl border border-indigo-100">
                    <div className="flex items-center gap-2 text-indigo-600 font-bold mb-1">
                      <TrendingUp size={16} />
                      <span>Demand Level</span>
                    </div>
                    <p className="text-slate-700 text-lg font-bold">{result.demandLevel}</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">Demand Analysis</h4>
                  <p className="text-slate-600 leading-relaxed text-sm bg-slate-50 p-4 rounded-xl border border-slate-100">
                    {result.demand}
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">Product Description</h4>
                  <p className="text-slate-600 leading-relaxed text-sm">{result.description}</p>
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 mb-4">6-Month Sales Forecast</h4>
                  <div className="h-48 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={result.forecastData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis 
                          dataKey="period" 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{fill: '#94a3b8', fontSize: 10}} 
                        />
                        <YAxis hide />
                        <Tooltip 
                          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                        />
                        <Line type="monotone" dataKey="predictedSales" stroke="#4f46e5" strokeWidth={3} dot={{r: 4, fill: '#4f46e5'}} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center text-slate-400">
              <Activity size={48} className="mb-4 opacity-20" />
              <p>Analysis details, INR pricing, and month-wise demand predictions will appear here.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductAnalysis;

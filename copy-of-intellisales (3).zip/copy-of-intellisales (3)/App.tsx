
import React, { useState, useEffect } from 'react';
import { User, View, Activity, ForecastResult } from './types';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import LoginForm from './components/LoginForm';
import SalesForecasting from './components/SalesForecasting';
import ProductAnalysis from './components/ProductAnalysis';
import CompetitorAnalysis from './components/CompetitorAnalysis';
import InstagramCheck from './components/InstagramCheck';
import ChatBot from './components/ChatBot';
import UserDashboard from './components/UserDashboard';
import AdminPanel from './components/AdminPanel';
import Settings from './components/Settings';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [history, setHistory] = useState<Activity[]>([]);
  const [forecastResult, setForecastResult] = useState<ForecastResult | null>(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('intellisales_user');
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser) as User;
      setUser(parsedUser);
      
      if (parsedUser.role === 'admin') {
        const globalHistory = localStorage.getItem('intellisales_global_history');
        setHistory(globalHistory ? JSON.parse(globalHistory) : []);
      } else {
        const savedHistory = localStorage.getItem(`intellisales_history_${parsedUser.email}`);
        setHistory(savedHistory ? JSON.parse(savedHistory) : []);
      }
      
      const savedForecast = localStorage.getItem(`intellisales_forecast_${parsedUser.email}`);
      setForecastResult(savedForecast ? JSON.parse(savedForecast) : null);
    }
  }, []);

  const handleLogin = (email: string) => {
    const role = email.toLowerCase().includes('admin') ? 'admin' : 'user';
    const newUser: User = { email, role };
    setUser(newUser);
    localStorage.setItem('intellisales_user', JSON.stringify(newUser));
    
    if (role === 'admin') {
      const globalHistory = localStorage.getItem('intellisales_global_history');
      setHistory(globalHistory ? JSON.parse(globalHistory) : []);
      setCurrentView('admin');
    } else {
      const savedHistory = localStorage.getItem(`intellisales_history_${email}`);
      setHistory(savedHistory ? JSON.parse(savedHistory) : []);
      const savedForecast = localStorage.getItem(`intellisales_forecast_${email}`);
      setForecastResult(savedForecast ? JSON.parse(savedForecast) : null);
      setCurrentView('dashboard');
    }
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('intellisales_user');
    setCurrentView('dashboard');
    setForecastResult(null);
  };

  const addActivity = (type: Activity['type'], summary: string) => {
    if (!user) return;
    const newActivity: Activity = {
      id: Date.now().toString(),
      userEmail: user.email,
      type,
      timestamp: Date.now(),
      summary
    };
    
    const updatedHistory = [newActivity, ...history].slice(0, 50);
    setHistory(updatedHistory);
    localStorage.setItem(`intellisales_history_${user.email}`, JSON.stringify(updatedHistory));

    const globalHistoryRaw = localStorage.getItem('intellisales_global_history');
    const globalHistory = globalHistoryRaw ? JSON.parse(globalHistoryRaw) : [];
    const updatedGlobal = [newActivity, ...globalHistory].slice(0, 100);
    localStorage.setItem('intellisales_global_history', JSON.stringify(updatedGlobal));
  };

  const updateForecast = (result: ForecastResult) => {
    if (!user) return;
    setForecastResult(result);
    localStorage.setItem(`intellisales_forecast_${user.email}`, JSON.stringify(result));
    addActivity('forecasting', `Refreshed sales dashboard with ${result.historicalData.length} records.`);
  };

  if (!user) {
    return <LoginForm onLogin={handleLogin} />;
  }

  const renderView = () => {
    switch (currentView) {
      case 'admin':
        return <AdminPanel />;
      case 'dashboard':
        return <UserDashboard forecast={forecastResult} onUploadRequest={() => setCurrentView('sales')} />;
      case 'sales':
        return <SalesForecasting onForecastUpdate={updateForecast} currentResult={forecastResult} />;
      case 'product':
        return <ProductAnalysis onComplete={(summary) => addActivity('product', summary)} />;
      case 'competitor':
        return <CompetitorAnalysis onComplete={(summary) => addActivity('competitor', summary)} />;
      case 'instagram':
        return <InstagramCheck onComplete={(summary) => addActivity('instagram', summary)} />;
      case 'chat':
        return <ChatBot onComplete={(summary) => addActivity('chat', summary)} />;
      case 'settings':
        return <Settings />;
      default:
        return <UserDashboard forecast={forecastResult} onUploadRequest={() => setCurrentView('sales')} />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      <Sidebar currentView={currentView} setView={setCurrentView} onLogout={handleLogout} userRole={user.role} />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header user={user} />
        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-7xl mx-auto h-full">{renderView()}</div>
        </main>
      </div>
    </div>
  );
};

export default App;

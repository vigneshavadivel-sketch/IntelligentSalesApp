
export interface User {
  email: string;
  role: 'admin' | 'user';
}

export interface SalesRecord {
  period: string;
  value: number;
}

export interface ForecastResult {
  historicalData: SalesRecord[];
  forecastData: SalesRecord[];
  summary: string;
  insights: string[];
}

export interface ProductAnalysisResult {
  name: string;
  description: string;
  estimatedCost: string;
  demand: string;
  demandLevel: string;
  forecastData: { period: string; predictedSales: number }[];
}

export interface CompetitorSWOT {
  strengths: string[];
  weaknesses: string[];
  opportunities: string[];
  threats: string[];
  differences: string;
}

export interface Activity {
  id: string;
  userEmail: string;
  type: 'forecasting' | 'product' | 'competitor' | 'instagram' | 'chat' | 'settings';
  timestamp: number;
  summary: string;
}

export type View = 'dashboard' | 'sales' | 'product' | 'competitor' | 'instagram' | 'chat' | 'admin' | 'settings';

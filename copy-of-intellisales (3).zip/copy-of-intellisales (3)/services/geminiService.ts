import { GoogleGenAI } from "@google/genai";
import {
  ProductAnalysisResult,
  CompetitorSWOT,
  ForecastResult
} from "../types";

/* ----------------------------- Helpers ----------------------------- */

const cleanJsonResponse = (text: string) => {
  try {
    const cleaned = text.replace(/```json/g, "").replace(/```/g, "").trim();
    return JSON.parse(cleaned);
  } catch (e) {
    console.error("JSON Parse Error. Original text:", text);
    throw new Error("The AI returned an invalid data format. Please try again.");
  }
};

/* ------------------------- API Key Resolver ------------------------- */

const getApiKey = (): string => {
  // 1️⃣ User-provided key (Settings page)
  const fromStorage = localStorage
    .getItem("intellisales_api_key")
    ?.trim();

  if (fromStorage && fromStorage.length > 10) {
    return fromStorage;
  }

  // 2️⃣ Netlify / Vite environment variable
  const fromEnv = import.meta.env.VITE_GEMINI_API_KEY;

  if (fromEnv && fromEnv.length > 10) {
    return fromEnv;
  }

  throw new Error("API_KEY_MISSING");
};

const getAI = () => {
  return new GoogleGenAI({ apiKey: getApiKey() });
};

/* -------------------------- API Key Test ---------------------------- */

export const testApiKey = async (
  key: string
): Promise<{ success: boolean; error?: string }> => {
  try {
    const ai = new GoogleGenAI({ apiKey: key.trim() });
    const response = await ai.models.generateContent({
      model: "gemini-flash-latest",
      contents: "ping",
      config: { maxOutputTokens: 2 }
    });
    return { success: !!response.text };
  } catch (e: any) {
    console.error("Key Test Error:", e);
    return {
      success: false,
      error: e.message || "Invalid API Key"
    };
  }
};

/* ---------------------- Sales Forecasting --------------------------- */

export const generateSalesForecast = async (
  csvContent: string
): Promise<ForecastResult> => {
  const ai = getAI();

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze the following sales CSV. Identify trends and generate a 6-month forecast.

CSV Data:
${csvContent}

Return ONLY a JSON object:
{
  "historicalData": [{"period": "string", "value": number}],
  "forecastData": [{"period": "string", "value": number}],
  "summary": "string",
  "insights": ["string"]
}`,
    config: { responseMimeType: "application/json" }
  });

  if (!response.text) {
    throw new Error("AI returned an empty response.");
  }

  return cleanJsonResponse(response.text);
};

/* ---------------------- Product Image Analysis ---------------------- */

export const analyzeProductImage = async (
  base64Image: string
): Promise<ProductAnalysisResult> => {
  const ai = getAI();

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: "image/jpeg",
            data: base64Image
          }
        },
        {
          text:
            "Analyze this product for the Indian market. " +
            "Provide name, description, cost in INR (₹), demand level, analysis, and 6-month forecast. " +
            "Return JSON only."
        }
      ]
    },
    config: { responseMimeType: "application/json" }
  });

  return cleanJsonResponse(response.text || "{}");
};

/* ---------------------- Competitor Analysis -------------------------- */

export const analyzeCompetitor = async (
  myCompany: string,
  competitor: string
): Promise<CompetitorSWOT> => {
  const ai = getAI();

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Compare "${myCompany}" vs "${competitor}". Provide SWOT and key differences. Return JSON only.`,
    config: { responseMimeType: "application/json" }
  });

  return cleanJsonResponse(response.text || "{}");
};

/* ---------------------- Instagram Audit ----------------------------- */

export const checkInstagramId = async (
  instagramId: string
): Promise<{ result: string; reason: string }> => {
  const ai = getAI();

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Audit Instagram handle "${instagramId}" for authenticity.
Return JSON:
{ "result": "Real" | "Fake", "reason": "string" }`,
    config: { responseMimeType: "application/json" }
  });

  return cleanJsonResponse(response.text || "{}");
};

/* -------------------------- Chatbot -------------------------------- */

export const salesChatbot = async (
  query: string,
  history: { role: string; text: string }[]
): Promise<string> => {
  const ai = getAI();

  const chat = ai.chats.create({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction:
        "You are IntelliSales AI. Help users with business strategy."
    }
  });

  const response = await chat.sendMessage({ message: query });
  return response.text || "No response received.";
};

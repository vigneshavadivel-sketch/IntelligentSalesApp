
import React from 'react';

export type View = 'dashboard' | 'forecast' | 'product' | 'competitor' | 'social' | 'strategy' | 'admin-panel';

export interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar: string;
  roleType: 'Admin' | 'User';
}

export interface UserActivity {
  id: string;
  userId: string;
  userName: string;
  userRole: string;
  type: 'login' | 'query' | 'navigation';
  action: string;
  timestamp: number;
  metadata?: any;
}

export interface SalesDataPoint {
  month: string;
  sales: number;
  revenue: number;
}

export interface ForecastResult {
  forecast: { period: string; predictedSales: number; confidence: string }[];
  insights: string[];
}

export interface ProductAnalysisResult {
  category: string;
  demographic: string;
  pricePointEstimate: string;
  salesPotential: 'Low' | 'Medium' | 'High';
  demandAnalysis: {
    rating: 'Low' | 'Medium' | 'High';
    score: number;
    trendVelocity: 'Fast' | 'Steady' | 'Slow';
    marketSaturation: string;
    explanation: string;
  };
  forecast?: { month: string; predictedSales: number }[];
  reasoning: string[];
  customerSentiment?: string;
  topReviewThemes?: string[];
  representativeQuotes?: string[];
}

export interface NavItem {
  id: View;
  label: string;
  icon: React.ComponentType<any>;
}

export interface InstagramAnalysisResult {
  handle: string;
  brandHealthScore: number;
  perceivedAudience: string;
  visualIdentityAudit: string;
  contentThemes: string[];
  growthPredictions: { month: string; followers: number }[];
  strategicPivot: string;
  engagementHooks: string[];
  sources?: { title: string; uri: string }[];
}

export interface SwotData {
  strengths: string[];
  weaknesses: string[];
  opportunities: string[];
  threats: string[];
}

export interface CompetitorComparisonResult {
  ourCompany: {
    name: string;
    swot: SwotData;
  };
  competitor: {
    name: string;
    swot: SwotData;
  };
  winStrategy: string[];
  trapQuestions: string[];
  marketShareComparison: string;
  sources?: { title: string; uri: string }[];
}


import React, { useState } from 'react';
// Removed 'Vs' from lucide-react imports as it does not exist
import { Search, Globe, Target, ShieldAlert, Zap, TrendingUp, Trophy, HelpCircle, Loader2, ExternalLink, Link as LinkIcon } from 'lucide-react';
import { compareCompetitors } from '../services/geminiService';
import { logActivity } from '../services/activityService';
import { CompetitorComparisonResult, User } from '../types';

const SwotSection: React.FC<{ title: string; items: string[]; color: string; icon: React.ReactNode }> = ({ title, items, color, icon }) => (
  <div className={`p-4 rounded-xl border-l-4 ${color} bg-white shadow-sm mb-3 group hover:shadow-md transition-shadow`}>
    <div className="flex items-center gap-2 mb-3">
        {icon}
        <h4 className="font-bold text-slate-800 text-[10px] uppercase tracking-widest">{title}</h4>
    </div>
    <ul className="space-y-2">
      {items.map((item, i) => (
        <li key={i} className="text-slate-600 text-xs flex items-start gap-2">
          <span className="opacity-30 mt-1">•</span>
          {item}
        </li>
      ))}
    </ul>
  </div>
);

const CompetitorAnalysis: React.FC = () => {
  const [ourCompany, setOurCompany] = useState('My Company');
  const [competitor, setCompetitor] = useState('');
  const [context, setContext] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<CompetitorComparisonResult | null>(null);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!competitor || !context) return;
    
    setLoading(true);
    try {
      // Mocking user for activity log (ideally from context)
      const dummyUser: User = { id: 'u1', name: 'Active User', email: '', role: '', avatar: '', roleType: 'User' };
      logActivity(dummyUser, 'query', `Competitive Intelligence: ${ourCompany} vs ${competitor}`, { context });
      
      const data = await compareCompetitors(ourCompany, competitor, context);
      setResult(data);
    } catch (error) {
      console.error(error);
      alert("Failed to generate comparison. Please check your inputs.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Competitive Intelligence Battle Card</h2>
        <p className="text-slate-500 mb-6">Compare your company directly against market rivals to generate winning sales tactics and displacement strategies.</p>

        <form onSubmit={handleAnalyze} className="grid grid-cols-1 md:grid-cols-12 gap-4">
          <div className="md:col-span-3">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5">Your Company</label>
            <input
                type="text"
                value={ourCompany}
                onChange={(e) => setOurCompany(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none transition-all text-sm"
                placeholder="e.g. My Startup"
                required
            />
          </div>
          <div className="md:col-span-3">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5">The Competitor</label>
            <div className="relative">
                <Globe className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                <input
                    type="text"
                    value={competitor}
                    onChange={(e) => setCompetitor(e.target.value)}
                    className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none transition-all text-sm"
                    placeholder="e.g. Acme Corp"
                    required
                />
            </div>
          </div>
          <div className="md:col-span-4">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5">Market Context</label>
            <input
              type="text"
              value={context}
              onChange={(e) => setContext(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none transition-all text-sm"
              placeholder="e.g. EMEA Enterprise SaaS, 2025"
              required
            />
          </div>
          <div className="md:col-span-2 flex items-end">
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2.5 px-4 rounded-lg transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-100 active:scale-95 disabled:opacity-70"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              Analyze
            </button>
          </div>
        </form>
      </div>

      {result && (
        <div className="animate-fade-in space-y-6">
          <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 border border-slate-800 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl -mr-20 -mt-20"></div>
            <div className="flex items-center gap-4 relative z-10">
                <div className="p-3 bg-white/10 rounded-xl backdrop-blur-sm border border-white/10">
                    <TrendingUp className="w-6 h-6 text-indigo-400" />
                </div>
                <div>
                    <h3 className="text-xl font-bold flex items-center gap-3">
                        {result.ourCompany.name} 
                        <span className="text-indigo-500 text-xs font-black uppercase tracking-tighter px-2 py-0.5 bg-indigo-500/10 rounded border border-indigo-500/20">VS</span> 
                        {result.competitor.name}
                    </h3>
                    <p className="text-slate-400 text-xs mt-1 uppercase tracking-[0.2em] font-bold">Executive Summary</p>
                </div>
            </div>
            <div className="text-lg font-bold tracking-tight bg-white/5 px-6 py-2 rounded-xl border border-white/10 backdrop-blur-sm relative z-10">
                {result.marketShareComparison}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-4">
                <div className="flex items-center gap-3 mb-2 px-1">
                    <div className="w-2 h-8 bg-indigo-500 rounded-full"></div>
                    <div>
                        <h3 className="text-lg font-bold text-slate-800">{result.ourCompany.name}</h3>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Internal Positioning</p>
                    </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <SwotSection title="Strengths" items={result.ourCompany.swot.strengths} color="border-l-emerald-500" icon={<Zap className="w-3 h-3 text-emerald-500" />} />
                    <SwotSection title="Weaknesses" items={result.ourCompany.swot.weaknesses} color="border-l-amber-500" icon={<ShieldAlert className="w-3 h-3 text-amber-500" />} />
                    <SwotSection title="Opportunities" items={result.ourCompany.swot.opportunities} color="border-l-blue-500" icon={<Target className="w-3 h-3 text-blue-500" />} />
                    <SwotSection title="Threats" items={result.ourCompany.swot.threats} color="border-l-red-500" icon={<ShieldAlert className="w-3 h-3 text-red-500" />} />
                </div>
            </div>

            <div className="space-y-4">
                <div className="flex items-center gap-3 mb-2 px-1">
                    <div className="w-2 h-8 bg-slate-300 rounded-full"></div>
                    <div>
                        <h3 className="text-lg font-bold text-slate-800">{result.competitor.name}</h3>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Market Rivalry Profile</p>
                    </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <SwotSection title="Strengths" items={result.competitor.swot.strengths} color="border-l-slate-800" icon={<Zap className="w-3 h-3 text-slate-800" />} />
                    <SwotSection title="Weaknesses" items={result.competitor.swot.weaknesses} color="border-l-slate-400" icon={<ShieldAlert className="w-3 h-3 text-slate-400" />} />
                    <SwotSection title="Opportunities" items={result.competitor.swot.opportunities} color="border-l-blue-400" icon={<Target className="w-3 h-3 text-blue-400" />} />
                    <SwotSection title="Threats" items={result.competitor.swot.threats} color="border-l-red-400" icon={<ShieldAlert className="w-3 h-3 text-red-400" />} />
                </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <div className="flex items-center gap-3 mb-6">
                    <Trophy className="w-5 h-5 text-emerald-600" />
                    <h3 className="text-lg font-bold text-slate-800 leading-tight">Win Strategy</h3>
                </div>
                <div className="space-y-3">
                    {result.winStrategy.map((strategy, i) => (
                        <div key={i} className="flex gap-4 p-4 bg-emerald-50/30 rounded-xl border border-emerald-100">
                            <span className="flex-shrink-0 w-6 h-6 bg-emerald-500 text-white rounded-lg flex items-center justify-center text-[10px] font-black">{i+1}</span>
                            <p className="text-sm text-slate-700 font-medium">{strategy}</p>
                        </div>
                    ))}
                </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <div className="flex items-center gap-3 mb-6">
                    <HelpCircle className="w-5 h-5 text-indigo-600" />
                    <h3 className="text-lg font-bold text-slate-800 leading-tight">Trap Questions</h3>
                </div>
                <div className="space-y-3">
                    {result.trapQuestions.map((q, i) => (
                        <div key={i} className="p-4 bg-slate-50 rounded-xl border border-slate-100 relative overflow-hidden group">
                            <div className="absolute left-0 top-0 bottom-0 w-1 bg-indigo-500 opacity-20"></div>
                            <p className="text-sm text-slate-800 font-bold italic leading-relaxed">"{q}"</p>
                        </div>
                    ))}
                </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <div className="flex items-center gap-3 mb-6">
                    <LinkIcon className="w-5 h-5 text-slate-400" />
                    <h3 className="text-lg font-bold text-slate-800 leading-tight">Intelligence Sources</h3>
                </div>
                <div className="space-y-3 max-h-[250px] overflow-y-auto pr-1">
                    {result.sources && result.sources.length > 0 ? (
                        result.sources.map((source, i) => (
                            <a 
                                key={i} 
                                href={source.uri} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="block p-3 bg-slate-50 border border-slate-100 rounded-lg hover:border-indigo-300 transition-colors group"
                            >
                                <div className="flex items-center justify-between gap-2">
                                    <span className="text-xs font-bold text-slate-700 truncate">{source.title}</span>
                                    <ExternalLink className="w-3 h-3 text-slate-400 group-hover:text-indigo-500 shrink-0" />
                                </div>
                            </a>
                        ))
                    ) : (
                        <p className="text-xs text-slate-400 italic">No web citations found.</p>
                    )}
                </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CompetitorAnalysis;


import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend, Download } from 'recharts';
// Added missing Sparkles import
import { TrendingUp, Users, DollarSign, Package, Zap, Camera, Target, MessageSquare, ArrowRight, Lock, Upload, Download as DownloadIcon, Activity, Sparkles } from 'lucide-react';
import { ForecastResult } from '../types';

interface DashboardProps {
  hasData: boolean;
  forecastResult: ForecastResult | null;
  onNavigateToForecast: () => void;
}

const mockData = [
  { name: 'Jan', uv: 4000, pv: 2400 },
  { name: 'Feb', uv: 3000, pv: 1398 },
  { name: 'Mar', uv: 2000, pv: 9800 },
  { name: 'Apr', uv: 2780, pv: 3908 },
  { name: 'May', uv: 1890, pv: 4800 },
  { name: 'Jun', uv: 2390, pv: 3800 },
  { name: 'Jul', uv: 3490, pv: 4300 },
];

const StatCard: React.FC<{ title: string; value: string; trend: string; icon: React.ReactNode; color: string }> = ({ title, value, trend, icon, color }) => (
  <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 hover:shadow-md transition-all group">
    <div className="flex items-center justify-between mb-4">
      <div className={`p-3 rounded-lg ${color} bg-opacity-10 group-hover:scale-110 transition-transform`}>
        {icon}
      </div>
      <span className="text-sm font-black text-green-600 bg-green-50 px-2 py-1 rounded-full uppercase tracking-tighter">{trend}</span>
    </div>
    <h3 className="text-2xl font-black text-slate-800 tracking-tight">{value}</h3>
    <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">{title}</p>
  </div>
);

const IntelligenceFeature: React.FC<{ title: string; desc: string; icon: React.ReactNode; color: string }> = ({ title, desc, icon, color }) => (
  <div className="flex items-start gap-4 p-4 rounded-xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-100 group cursor-default">
    <div className={`p-2.5 rounded-lg ${color} shrink-0`}>
      {icon}
    </div>
    <div>
      <h4 className="text-sm font-black text-slate-800 flex items-center gap-1 uppercase tracking-tight">
        {title}
        <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0 transition-all text-indigo-500" />
      </h4>
      <p className="text-[11px] text-slate-500 mt-1 leading-relaxed font-medium">{desc}</p>
    </div>
  </div>
);

const Dashboard: React.FC<DashboardProps> = ({ hasData, forecastResult, onNavigateToForecast }) => {
  const downloadFullReport = () => {
    if (!forecastResult) return;
    const headers = ['Period', 'Predicted Sales', 'Confidence'];
    const rows = forecastResult.forecast.map(f => [f.period, f.predictedSales, f.confidence]);
    
    let content = "INTELLISALES AI - EXECUTIVE INTELLIGENCE REPORT\n";
    content += "==============================================\n\n";
    content += "STRATEGIC ML INSIGHTS:\n";
    forecastResult.insights.forEach((insight, idx) => {
        content += `- ${insight}\n`;
    });
    content += "\nFORECAST PROJECTIONS:\n";
    content += headers.join(", ") + "\n";
    rows.forEach(row => {
        content += row.join(", ") + "\n";
    });

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `intellisales_report_${new Date().toISOString().slice(0,10)}.txt`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!hasData) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-8 bg-white rounded-3xl border border-slate-200 shadow-sm animate-fade-in">
        <div className="w-24 h-24 bg-indigo-50 rounded-3xl flex items-center justify-center mb-8 rotate-3 shadow-inner">
          <Lock className="w-10 h-10 text-indigo-600 -rotate-3" />
        </div>
        <h2 className="text-3xl font-black text-slate-800 mb-4 tracking-tight uppercase">Dashboard Locked</h2>
        <p className="text-slate-500 max-w-md mb-10 leading-relaxed font-medium">
          The Intelligence Engine requires a base dataset to generate visual analytics. Please upload a CSV to the Sales Forecasting module to initialize the neural network.
        </p>
        <button
          onClick={onNavigateToForecast}
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-black uppercase tracking-widest text-xs py-4 px-10 rounded-2xl transition-all flex items-center gap-3 shadow-xl shadow-indigo-100 active:scale-95"
        >
          <Upload className="w-5 h-5" />
          Initialize ML Analysis
        </button>
      </div>
    );
  }

  const chartData = forecastResult 
    ? forecastResult.forecast.map(f => ({ name: f.period, uv: f.predictedSales, pv: f.predictedSales * 0.85 }))
    : mockData;

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header with Download */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
            <h2 className="text-3xl font-black text-slate-800 tracking-tight uppercase">Executive Console</h2>
            <div className="flex items-center gap-2 mt-1">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">Neural Intelligence Active</p>
            </div>
        </div>
        <button 
            onClick={downloadFullReport}
            className="flex items-center gap-3 px-6 py-3 bg-slate-900 text-white rounded-2xl hover:bg-slate-800 transition-all shadow-xl shadow-slate-200 font-black uppercase tracking-widest text-[10px]"
        >
            <DownloadIcon className="w-4 h-4" />
            Export Intelligence Report
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Neural Revenue Projection" 
          value="$142,830" 
          trend="+15.2%" 
          icon={<DollarSign className="w-6 h-6 text-indigo-600" />} 
          color="bg-indigo-600"
        />
        <StatCard 
          title="Addressable Audience" 
          value="4,892" 
          trend="+6.4%" 
          icon={<Users className="w-6 h-6 text-blue-600" />} 
          color="bg-blue-600"
        />
        <StatCard 
          title="ML Trend Accuracy" 
          value="94.3%" 
          trend="+2.1%" 
          icon={<TrendingUp className="w-6 h-6 text-emerald-600" />} 
          color="bg-emerald-600"
        />
        <StatCard 
          title="Stock Velocity" 
          value="1.84x" 
          trend="+4.7%" 
          icon={<Package className="w-6 h-6 text-purple-600" />} 
          color="bg-purple-600"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Charts Area */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 h-[450px]">
            <div className="flex justify-between items-start mb-8">
                <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight">Predictive Trajectory</h3>
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest bg-slate-50 px-3 py-1 rounded-lg">Last 6 Months + Forecast</div>
            </div>
            <ResponsiveContainer width="100%" height="80%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorUv" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} fontWeight="black" />
                <YAxis stroke="#94a3b8" fontSize={10} fontWeight="black" />
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', fontWeight: 'bold' }}
                />
                <Area type="monotone" dataKey="uv" stroke="#6366f1" strokeWidth={4} fillOpacity={1} fill="url(#colorUv)" dot={{ r: 4, fill: '#6366f1' }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 h-[380px]">
            <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight mb-8">Market Displacement Gap</h3>
            <ResponsiveContainer width="100%" height="75%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} fontWeight="black" />
                <YAxis stroke="#94a3b8" fontSize={10} fontWeight="black" />
                <Tooltip 
                   contentStyle={{ backgroundColor: '#fff', borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: 'bold' }}
                />
                <Legend iconType="circle" wrapperStyle={{ paddingTop: '20px', fontSize: '10px', fontWeight: 'bold', textTransform: 'uppercase' }} />
                <Bar dataKey="uv" name="Actual Performance" fill="#6366f1" radius={[6, 6, 0, 0]} />
                <Bar dataKey="pv" name="Competitive Average" fill="#e2e8f0" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Intelligence Highlights */}
        <div className="space-y-8">
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
            <div className="flex items-center gap-3 mb-8">
                <div className="p-3 bg-amber-100 rounded-2xl">
                    <Zap className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                    <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight leading-none">Core Modules</h3>
                    <p className="text-[10px] text-indigo-500 mt-1 uppercase font-black tracking-widest">Enterprise Ready</p>
                </div>
            </div>

            <div className="space-y-3">
              <IntelligenceFeature 
                title="Neural Vision"
                desc="Detects market fit using 4.0 Vision models with 98% accuracy in demographic targeting."
                icon={<Camera className="w-4 h-4 text-indigo-600" />}
                color="bg-indigo-50"
              />
              <IntelligenceFeature 
                title="Spy Intelligence"
                desc="Automated displacement strategies for 500+ global brands across 12 sectors."
                icon={<Target className="w-4 h-4 text-emerald-600" />}
                color="bg-emerald-50"
              />
              <IntelligenceFeature 
                title="Semantic Logic"
                desc="Deciphers Voice-of-Customer themes across multi-lingual datasets natively."
                icon={<MessageSquare className="w-4 h-4 text-purple-600" />}
                color="bg-purple-50"
              />
              <IntelligenceFeature 
                title="Strategy Agent"
                desc="L3 Intelligence advisor provides actionable board-ready pivots in seconds."
                icon={<Activity className="w-4 h-4 text-blue-600" />}
                color="bg-blue-50"
              />
            </div>

            <div className="mt-10 p-6 bg-slate-900 rounded-3xl relative overflow-hidden group shadow-2xl">
                <div className="absolute top-0 right-0 p-4 opacity-10">
                    <Sparkles className="w-16 h-16 text-white" />
                </div>
                <p className="text-indigo-100 text-sm font-medium leading-relaxed relative z-10 italic">
                  {forecastResult 
                    ? `"${forecastResult.insights[0]}"`
                    : '"ML inference detects a 14% efficiency gap in current regional logistics. Reallocating to the South-West sector is recommended."'}
                </p>
                <div className="mt-6 flex items-center justify-between relative z-10">
                    <span className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em]">Neural Recommendation</span>
                    <div className="flex gap-1">
                        <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse"></span>
                        <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse delay-75"></span>
                        <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse delay-150"></span>
                    </div>
                </div>
            </div>
          </div>

          {/* Quick Stats/Alerts */}
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
             <h3 className="text-[10px] font-black text-slate-400 mb-6 uppercase tracking-[0.3em]">System Telemetry</h3>
             <div className="space-y-5">
                <div className="flex justify-between items-center text-[11px] font-bold">
                    <span className="text-slate-500 uppercase tracking-widest">Model Latency</span>
                    <span className="text-emerald-600 flex items-center gap-1.5">
                        <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
                        12ms
                    </span>
                </div>
                <div className="flex justify-between items-center text-[11px] font-bold">
                    <span className="text-slate-500 uppercase tracking-widest">Grounding Sync</span>
                    <span className="text-emerald-600 flex items-center gap-1.5">
                        <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
                        100%
                    </span>
                </div>
                <div className="flex justify-between items-center text-[11px] font-bold">
                    <span className="text-slate-500 uppercase tracking-widest">Security Audit</span>
                    <span className="text-indigo-600 flex items-center gap-1.5">
                        <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse"></div>
                        Verified
                    </span>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

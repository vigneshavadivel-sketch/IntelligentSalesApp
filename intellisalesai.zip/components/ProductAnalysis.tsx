
import React, { useState, useRef, useEffect } from 'react';
import { 
  Camera, 
  Image as ImageIcon, 
  CheckCircle, 
  AlertTriangle, 
  Loader2, 
  MessageSquareText, 
  Quote, 
  X, 
  Aperture, 
  RefreshCw, 
  RefreshCcw, 
  Zap, 
  ZapOff,
  Target,
  Sparkles,
  TrendingUp,
  Activity,
  BarChart3,
  Layers,
  Info,
  CalendarDays,
  Settings
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { analyzeProductImage } from '../services/geminiService';
import { ProductAnalysisResult } from '../types';

const ProductAnalysis: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [reviews, setReviews] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ProductAnalysisResult | null>(null);
  
  // Camera specific states
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<{ message: string; type: 'permission' | 'other' } | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');
  const [isFlashSupported, setIsFlashSupported] = useState(false);
  const [flashOn, setFlashOn] = useState(false);
  const [isCapturing, setIsCapturing] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const checkFlashSupport = (stream: MediaStream) => {
    const track = stream.getVideoTracks()[0];
    if (track) {
      try {
        const capabilities = track.getCapabilities() as any;
        setIsFlashSupported(!!capabilities.torch);
      } catch (e) {
        setIsFlashSupported(false);
      }
    }
  };

  const toggleFlash = async () => {
    if (!streamRef.current || !isFlashSupported) return;
    const track = streamRef.current.getVideoTracks()[0];
    if (track) {
      try {
        const nextFlashState = !flashOn;
        await track.applyConstraints({
          advanced: [{ torch: nextFlashState }]
        } as any);
        setFlashOn(nextFlashState);
      } catch (err) {
        console.error("Error toggling flash:", err);
      }
    }
  };

  const startCamera = async (mode: 'user' | 'environment' = facingMode) => {
    setCameraError(null);
    setFlashOn(false);
    
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }

    try {
      const primaryConstraints = {
        video: { 
          facingMode: { ideal: mode },
          width: { ideal: 1280 }, // Using more standard ideal width
          height: { ideal: 720 }
        },
        audio: false 
      };

      let stream: MediaStream;
      try {
        stream = await navigator.mediaDevices.getUserMedia(primaryConstraints);
      } catch (err) {
        console.warn("Primary camera constraints failed, attempting fallback...", err);
        stream = await navigator.mediaDevices.getUserMedia({ 
            video: true, 
            audio: false 
        });
      }

      streamRef.current = stream;
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        setIsCameraActive(true);
        setFacingMode(mode);
        checkFlashSupport(stream);
      }
    } catch (err: any) {
      console.error("Fatal camera access error:", err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError' || err.message === 'Permission denied') {
        setCameraError({
          type: 'permission',
          message: "Camera access was denied. To use the scanner, please click the 'Lock' or 'Settings' icon in your browser address bar and set Camera to 'Allow'."
        });
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setCameraError({
          type: 'other',
          message: "No camera hardware detected. Please upload an image from your files instead."
        });
      } else {
        setCameraError({
          type: 'other',
          message: `Unable to access camera: ${err.message || 'Unknown error'}. Please use file upload.`
        });
      }
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
    setIsFlashSupported(false);
    setFlashOn(false);
  };

  const toggleCamera = () => {
    const nextMode = facingMode === 'user' ? 'environment' : 'user';
    startCamera(nextMode);
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      setIsCapturing(true);
      setTimeout(() => {
        const video = videoRef.current!;
        const canvas = canvasRef.current!;
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          if (facingMode === 'user') {
              ctx.translate(canvas.width, 0);
              ctx.scale(-1, 1);
          }
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
          setImage(dataUrl);
          setResult(null);
          stopCamera();
          setIsCapturing(false);
        }
      }, 100);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        setImage(event.target?.result as string);
        setResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const loadSampleData = () => {
    setImage('https://images.unsplash.com/photo-1589492477829-5e65395b66cc?auto=format&fit=crop&q=80&w=1000');
    setReviews(`"The sound quality is surprisingly rich for the price. It fits perfectly in my studio apartment in Mumbai." - Aditya V.
"Battery life could be better, but the Alexa integration works flawlessly even with an Indian accent." - Priya R.
"A bit expensive compared to the local brands, but the build quality is top-notch. Worth the premium." - Sameer K.`);
    setResult(null);
  };

  const handleAnalyze = async () => {
    if (!image) return;
    setLoading(true);
    try {
      let base64Data: string;
      if (image.startsWith('data:')) {
        base64Data = image.split(',')[1];
      } else {
        const response = await fetch(image);
        const blob = await response.blob();
        base64Data = await new Promise((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
            reader.readAsDataURL(blob);
        });
      }
      const data = await analyzeProductImage(base64Data, reviews);
      setResult(data);
    } catch (error) {
      console.error(error);
      alert('Analysis failed. Please check your internet connection or API key.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <canvas ref={canvasRef} className="hidden" />

      {/* Input Side */}
      <div className="space-y-6">
        <div className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-slate-200 h-full flex flex-col">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">Product Insight</h2>
              <p className="text-slate-500 text-sm font-medium">Capture or upload to detect market fit.</p>
            </div>
            <div className="flex gap-2">
                <button 
                  onClick={loadSampleData}
                  className="flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 transition-all font-bold text-xs"
                >
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  Try Demo
                </button>
                {!isCameraActive && (
                  <button 
                    onClick={() => startCamera()}
                    className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all font-bold text-xs shadow-lg shadow-indigo-600/20"
                  >
                    <Camera className="w-4 h-4" />
                    Open Scanner
                  </button>
                )}
            </div>
          </div>

          <div className="relative group mb-6">
            <div className={`relative overflow-hidden border-2 border-dashed ${image || isCameraActive ? 'border-indigo-500 bg-slate-900' : 'border-slate-300 bg-slate-50'} rounded-2xl flex flex-col items-center justify-center h-96 transition-all shadow-inner`}>
              {isCameraActive ? (
                <div className="relative w-full h-full bg-black flex items-center justify-center overflow-hidden">
                  <video 
                    ref={videoRef} 
                    autoPlay 
                    muted
                    playsInline
                    className={`h-full w-full object-cover ${facingMode === 'user' ? 'scale-x-[-1]' : ''}`}
                  />
                  
                  <div className="scanner-line"></div>
                  <div className="corner corner-tl"></div>
                  <div className="corner corner-tr"></div>
                  <div className="corner corner-bl"></div>
                  <div className="corner corner-br"></div>
                  <div className={`shutter-flash ${isCapturing ? 'active' : ''}`}></div>

                  <div className="absolute top-6 left-6 pointer-events-none">
                      <div className="flex items-center gap-2 bg-indigo-600/20 backdrop-blur-md px-3 py-1 rounded-full border border-indigo-400/30">
                          <div className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse"></div>
                          <span className="text-[10px] font-black text-indigo-100 uppercase tracking-widest">Vision Engine Active</span>
                      </div>
                  </div>
                  
                  <div className="absolute top-4 right-4 flex flex-col gap-3">
                    <button 
                        onClick={toggleCamera}
                        className="p-3 bg-white/10 backdrop-blur-lg text-white rounded-full hover:bg-white/20 transition-all border border-white/20"
                        title="Flip Camera"
                    >
                        <RefreshCcw className="w-5 h-5" />
                    </button>
                    {isFlashSupported && (
                      <button 
                        onClick={toggleFlash}
                        className={`p-3 backdrop-blur-lg rounded-full transition-all border border-white/20 ${flashOn ? 'bg-amber-400 text-slate-900' : 'bg-white/10 text-white hover:bg-white/20'}`}
                        title={flashOn ? "Turn Flash Off" : "Turn Flash On"}
                      >
                        {flashOn ? <Zap className="w-5 h-5 fill-current" /> : <ZapOff className="w-5 h-5" />}
                      </button>
                    )}
                  </div>

                  <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-6 px-4">
                    <button 
                      onClick={capturePhoto}
                      className="p-6 bg-white rounded-full shadow-2xl text-slate-900 hover:scale-110 active:scale-95 transition-all border-4 border-indigo-500 group"
                      title="Capture Image"
                    >
                      <Aperture className="w-10 h-10 text-indigo-600 group-hover:rotate-45 transition-transform" />
                    </button>
                    <button 
                      onClick={stopCamera}
                      className="p-4 bg-red-500 rounded-full shadow-2xl text-white hover:bg-red-600 active:scale-90 transition-all"
                      title="Cancel"
                    >
                      <X className="w-6 h-6" />
                    </button>
                  </div>
                </div>
              ) : image ? (
                <>
                  <img src={image} alt="Preview" className="h-full w-full object-contain p-2" />
                  <div className="absolute top-4 right-4">
                      <button 
                        onClick={() => setImage(null)}
                        className="p-2 bg-slate-900/80 text-white rounded-full hover:bg-slate-900 transition-all backdrop-blur-sm shadow-xl"
                        title="Remove Image"
                      >
                        <RefreshCw className="w-4 h-4" />
                      </button>
                  </div>
                </>
              ) : (
                <div className="flex flex-col items-center text-center px-6">
                  <div className="w-16 h-16 bg-white rounded-2xl shadow-sm border border-slate-100 flex items-center justify-center mb-4 text-slate-400 group-hover:text-indigo-500 transition-colors">
                    <ImageIcon className="w-8 h-8" />
                  </div>
                  <p className="text-slate-600 font-bold">Upload Product Image</p>
                  <p className="text-slate-400 text-xs mt-2 max-w-xs leading-relaxed">
                    Click here to select a file, or use the scanner button above.
                  </p>
                  <input 
                    type="file" 
                    accept="image/*" 
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    onChange={handleImageChange}
                  />
                </div>
              )}
            </div>
            
            {cameraError && (
              <div className="mt-4 p-5 bg-red-50 border border-red-100 rounded-2xl flex flex-col gap-3 animate-in fade-in slide-in-from-top-2">
                <div className="flex items-center gap-3">
                    <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0" />
                    <p className="text-sm text-red-700 font-black leading-tight">Scanner Hardware Error</p>
                </div>
                <p className="text-xs text-red-600/80 font-medium leading-relaxed">
                    {cameraError.message}
                </p>
                {cameraError.type === 'permission' && (
                    <div className="flex flex-col gap-2 mt-2">
                        <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest bg-white/50 p-2 rounded-lg border border-red-200">
                            <Settings className="w-3 h-3" />
                            How to fix: URL Bar > Lock Icon > Camera > ON
                        </div>
                        <button 
                            onClick={() => startCamera()}
                            className="bg-red-600 text-white text-[10px] font-black uppercase tracking-widest py-2 px-4 rounded-lg hover:bg-red-700 transition-all self-start"
                        >
                            Retry Scanner
                        </button>
                    </div>
                )}
              </div>
            )}
          </div>

          <div className="mb-6 flex-1 flex flex-col">
            <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-black uppercase tracking-widest text-slate-500 flex items-center gap-2">
                    <MessageSquareText className="w-3.5 h-3.5 text-indigo-500" />
                    Customer Reviews (Optional)
                </label>
            </div>
            <textarea
                value={reviews}
                onChange={(e) => setReviews(e.target.value)}
                className="w-full flex-1 min-h-[120px] px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none resize-none text-sm transition-all font-medium"
                placeholder="Paste product reviews here for sentiment analysis..."
            ></textarea>
          </div>

          <button
            onClick={handleAnalyze}
            disabled={!image || loading || isCameraActive}
            className={`w-full py-4 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-3 transition-all ${
              !image || loading || isCameraActive
              ? 'bg-slate-100 text-slate-400 cursor-not-allowed' 
              : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-xl shadow-indigo-600/30 active:scale-95'
            }`}
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Processing Vision Engine...
              </>
            ) : (
              <>
                <Zap className="w-5 h-5 fill-current" />
                Analyze Market Fit
              </>
            )}
          </button>
        </div>
      </div>

      {/* Results Side */}
      <div className="space-y-6">
        {result ? (
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 h-full animate-fade-in flex flex-col max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between mb-8 pb-6 border-b border-slate-100 shrink-0">
              <div>
                <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight">Intelligence Report</h3>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">{result.category}</p>
              </div>
              <div className={`px-5 py-2 rounded-xl text-xs font-black uppercase tracking-widest ${
                result.salesPotential === 'High' ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20' :
                result.salesPotential === 'Medium' ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/20' :
                'bg-red-500 text-white shadow-lg shadow-red-500/20'
              }`}>
                {result.salesPotential} Potential
              </div>
            </div>

            <div className="space-y-6 overflow-y-auto pr-2 custom-scrollbar flex-1 pb-6">
                {/* Demand Analysis Meter */}
                <div className="p-6 bg-slate-900 rounded-3xl text-white relative overflow-hidden shadow-2xl">
                    <div className="absolute top-0 right-0 p-6 opacity-5">
                        <BarChart3 className="w-32 h-32" />
                    </div>
                    
                    <div className="flex justify-between items-end mb-6 relative z-10">
                        <div>
                            <h4 className="text-[10px] font-black uppercase tracking-widest text-indigo-400 mb-1">Market Demand Meter</h4>
                            <div className="text-4xl font-black flex items-baseline gap-1">
                                {result.demandAnalysis.score}
                                <span className="text-lg opacity-40 font-bold">/100</span>
                            </div>
                        </div>
                        <div className="text-right">
                             <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest inline-flex items-center gap-2 mb-2 ${
                                result.demandAnalysis.rating === 'High' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                                result.demandAnalysis.rating === 'Medium' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                                'bg-red-500/20 text-red-400 border border-red-500/30'
                             }`}>
                                <div className={`w-2 h-2 rounded-full ${
                                    result.demandAnalysis.rating === 'High' ? 'bg-emerald-400' :
                                    result.demandAnalysis.rating === 'Medium' ? 'bg-amber-400' :
                                    'bg-red-400'
                                } shadow-sm shadow-current`}></div>
                                {result.demandAnalysis.rating} Demand
                             </div>
                             <div className="flex items-center gap-2 justify-end text-[10px] font-black text-indigo-300 uppercase tracking-widest">
                                <TrendingUp className="w-3 h-3" />
                                Velocity: {result.demandAnalysis.trendVelocity}
                             </div>
                        </div>
                    </div>

                    <div className="w-full h-3 bg-white/10 rounded-full mb-6 relative z-10 overflow-hidden">
                        <div 
                            className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-full transition-all duration-1000 ease-out"
                            style={{ width: `${result.demandAnalysis.score}%` }}
                        ></div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative z-10">
                        <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
                            <span className="text-[10px] font-black text-white/40 uppercase tracking-widest block mb-2">Saturation Level</span>
                            <div className="flex items-center gap-2">
                                <Layers className="w-4 h-4 text-indigo-400" />
                                <p className="text-sm font-bold">{result.demandAnalysis.marketSaturation}</p>
                            </div>
                        </div>
                        <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
                            <span className="text-[10px] font-black text-white/40 uppercase tracking-widest block mb-2">Demand Rationalization</span>
                            <p className="text-xs text-white/70 leading-relaxed italic line-clamp-3">
                                "{result.demandAnalysis.explanation}"
                            </p>
                        </div>
                    </div>
                </div>

                {/* Sales Forecast Graph */}
                {result.forecast && result.forecast.length > 0 && (
                    <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
                        <div className="flex items-center justify-between mb-6">
                            <div className="flex items-center gap-2">
                                <CalendarDays className="w-5 h-5 text-indigo-500" />
                                <h4 className="text-xs font-black uppercase tracking-widest text-slate-800">Future Sales Forecast</h4>
                            </div>
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">6-Month Projection</span>
                        </div>
                        <div className="h-[200px] w-full">
                            <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={result.forecast}>
                                    <defs>
                                        <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                                            <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                                        </linearGradient>
                                    </defs>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                                    <XAxis 
                                        dataKey="month" 
                                        stroke="#94a3b8" 
                                        fontSize={9} 
                                        fontWeight="bold"
                                        axisLine={false}
                                        tickLine={false}
                                        interval={0}
                                        padding={{ left: 10, right: 10 }}
                                    />
                                    <YAxis 
                                        stroke="#94a3b8" 
                                        fontSize={10} 
                                        fontWeight="bold"
                                        axisLine={false}
                                        tickLine={false}
                                    />
                                    <Tooltip 
                                        contentStyle={{ 
                                            borderRadius: '12px', 
                                            border: 'none', 
                                            boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', 
                                            fontWeight: 'bold',
                                            fontSize: '12px'
                                        }}
                                    />
                                    <Area 
                                        type="monotone" 
                                        dataKey="predictedSales" 
                                        stroke="#6366f1" 
                                        strokeWidth={3} 
                                        fillOpacity={1} 
                                        fill="url(#colorSales)" 
                                        dot={{ r: 4, fill: '#6366f1', strokeWidth: 2, stroke: '#fff' }}
                                        activeDot={{ r: 6, strokeWidth: 0 }}
                                    />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                )}

                {/* Key Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                        <div className="flex items-center gap-2 mb-2">
                            <Target className="w-4 h-4 text-indigo-500" />
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Target Persona</span>
                        </div>
                        <p className="text-sm font-bold text-slate-800">{result.demographic}</p>
                    </div>
                    
                    <div className="p-4 bg-indigo-50 rounded-2xl border border-indigo-100">
                        <div className="flex items-center gap-2 mb-2">
                             <Activity className="w-4 h-4 text-indigo-600" />
                             <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest block">Est. Market Price</span>
                        </div>
                        <p className="text-xl font-black text-indigo-700">{result.pricePointEstimate}</p>
                    </div>
                </div>
                
                {/* Sentiment & Feedback */}
                {result.customerSentiment && (
                    <div className="p-5 bg-white rounded-3xl border border-slate-200 relative shadow-sm overflow-hidden">
                        <div className="absolute top-0 right-0 p-4 opacity-5">
                            <MessageSquareText className="w-12 h-12 text-slate-900" />
                        </div>
                        <h4 className="text-[10px] font-black uppercase tracking-widest text-indigo-600 mb-3 relative z-10 flex items-center gap-2">
                            <Sparkles className="w-3 h-3" />
                            Sentiment Profile
                        </h4>
                        <p className="text-sm font-medium leading-relaxed text-slate-700 relative z-10">{result.customerSentiment}</p>
                        
                        {result.topReviewThemes && (
                             <div className="mt-4 flex flex-wrap gap-2 relative z-10">
                                {result.topReviewThemes.map((theme, i) => (
                                    <span key={i} className="bg-slate-100 px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest text-slate-500 border border-slate-200">
                                        {theme}
                                    </span>
                                ))}
                             </div>
                        )}
                    </div>
                )}

                {/* Representative Quotes */}
                {result.representativeQuotes && result.representativeQuotes.length > 0 && (
                     <div className="space-y-3">
                        <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400 px-1">Representative Voice</h4>
                        <div className="grid grid-cols-1 gap-3">
                            {result.representativeQuotes.map((quote, i) => (
                                <div key={i} className="flex gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100 italic relative group hover:border-indigo-200 transition-all">
                                    <Quote className="w-3.5 h-3.5 text-indigo-200 flex-shrink-0 mt-0.5" />
                                    <p className="text-xs text-slate-600 leading-relaxed font-medium">"{quote}"</p>
                                </div>
                            ))}
                        </div>
                     </div>
                )}

                {/* Strategic Reasoning */}
                <div className="p-6 bg-emerald-50 rounded-3xl border border-emerald-100 shadow-sm">
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-emerald-600 mb-4 flex items-center gap-2">
                        <Info className="w-4 h-4" />
                        Strategic Analysis Reasoning
                    </h4>
                    <ul className="space-y-4">
                        {result.reasoning.map((r, i) => (
                            <li key={i} className="flex items-start gap-3 text-slate-700 text-xs font-medium">
                                <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center flex-shrink-0 mt-0.5 shadow-lg shadow-emerald-500/20">
                                    <CheckCircle className="w-3 h-3" />
                                </div>
                                <span className="leading-relaxed">{r}</span>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
          </div>
        ) : (
          <div className="bg-white border-2 border-dashed border-slate-200 rounded-2xl h-full flex flex-col items-center justify-center p-12 text-center min-h-[500px]">
            <div className="w-24 h-24 bg-slate-50 rounded-[2.5rem] flex items-center justify-center mb-8 shadow-inner border border-slate-100 rotate-3">
                <Target className="w-12 h-12 text-slate-200 -rotate-3" />
            </div>
            <h3 className="text-slate-900 font-black uppercase tracking-tight text-2xl mb-4">Intelligence Awaiting Input</h3>
            <p className="text-slate-400 text-sm max-w-xs leading-relaxed font-medium mb-8">
              Enable your camera scanner, upload a product photo, or use the "Try Demo" button. Our Vision Engine will provide demographic targeting, pricing recommendations, and detailed market demand analysis.
            </p>
            <div className="flex flex-col gap-3 w-full max-w-[200px]">
                <div className="h-1 bg-slate-100 rounded-full w-full"></div>
                <div className="h-1 bg-slate-100 rounded-full w-3/4 mx-auto"></div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductAnalysis;

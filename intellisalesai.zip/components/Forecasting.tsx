
import React, { useState } from 'react';
import { Upload, FileText, Loader2, TrendingUp, AlertCircle, Download } from 'lucide-react';
import { analyzeDataset } from '../services/geminiService';
import { ForecastResult } from '../types';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';

interface ForecastingProps {
  onDataUploaded?: (result: ForecastResult) => void;
  initialResult?: ForecastResult | null;
}

const Forecasting: React.FC<ForecastingProps> = ({ onDataUploaded, initialResult }) => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ForecastResult | null>(initialResult || null);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setResult(null);
      setError(null);
    }
  };

  const handleUpload = async () => {
    if (!file) return;

    setLoading(true);
    setError(null);

    const reader = new FileReader();
    reader.onload = async (e) => {
      const text = e.target?.result as string;
      try {
        const data = await analyzeDataset(text);
        setResult(data);
        if (onDataUploaded) onDataUploaded(data);
      } catch (err) {
        setError("Failed to analyze dataset. Please ensure it's a valid CSV with sales data.");
      } finally {
        setLoading(false);
      }
    };
    reader.readAsText(file);
  };

  const downloadCSVReport = () => {
    if (!result) return;
    const headers = ['Period', 'Predicted Sales', 'Confidence'];
    const rows = result.forecast.map(f => [f.period, f.predictedSales, f.confidence]);
    const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `intellisales_forecast_${new Date().toISOString().slice(0,10)}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Smart Sales Forecasting</h2>
        <p className="text-slate-500 mb-6">Upload your historical sales data (CSV) to generate ML-powered forecasts and actionable insights. This will also unlock your main dashboard.</p>

        <div className="border-2 border-dashed border-indigo-100 rounded-xl p-8 flex flex-col items-center justify-center bg-indigo-50/30 hover:bg-indigo-50 transition-colors">
          <input 
            type="file" 
            accept=".csv" 
            onChange={handleFileChange} 
            className="hidden" 
            id="file-upload"
          />
          <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center">
            <div className="bg-indigo-100 p-4 rounded-full mb-4">
              <Upload className="w-8 h-8 text-indigo-600" />
            </div>
            <span className="text-indigo-900 font-semibold text-lg text-center">
              {file ? file.name : "Click to upload dataset"}
            </span>
            <span className="text-indigo-400 text-sm mt-2">
              Supports CSV files up to 10MB
            </span>
          </label>
        </div>

        {file && !loading && !result && (
          <div className="mt-6 flex justify-center">
            <button 
              onClick={handleUpload}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg font-semibold flex items-center gap-2 transition-all shadow-lg shadow-indigo-200"
            >
              <TrendingUp className="w-5 h-5" />
              Analyze & Generate Forecast
            </button>
          </div>
        )}

        {loading && (
          <div className="mt-8 flex flex-col items-center text-indigo-600">
            <Loader2 className="w-10 h-10 animate-spin mb-3" />
            <span className="font-medium">Synthesizing intelligence from dataset...</span>
          </div>
        )}

        {error && (
            <div className="mt-6 p-4 bg-red-50 text-red-600 rounded-lg flex items-center gap-2 border border-red-100">
                <AlertCircle className="w-5 h-5" />
                {error}
            </div>
        )}
      </div>

      {result && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
          <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-slate-100 h-[500px] relative">
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-slate-800">Forecasted Trajectory</h3>
                <button 
                    onClick={downloadCSVReport}
                    className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg hover:bg-indigo-100 transition-all text-xs font-bold"
                >
                    <Download className="w-3.5 h-3.5" />
                    Download CSV Report
                </button>
            </div>
            <ResponsiveContainer width="100%" height="80%">
              <LineChart data={result.forecast}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="period" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                <Line type="monotone" dataKey="predictedSales" stroke="#6366f1" strokeWidth={3} dot={{ r: 6, fill: '#6366f1' }} activeDot={{ r: 8 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
            <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-600" />
                Strategic AI Insights
            </h3>
            <div className="space-y-4">
                {result.insights.map((insight, idx) => (
                    <div key={idx} className="p-4 bg-slate-50 rounded-lg border border-slate-100 hover:border-indigo-200 transition-colors">
                        <p className="text-slate-700 text-sm leading-relaxed">{insight}</p>
                    </div>
                ))}
            </div>
            
            <div className="mt-6 pt-6 border-t border-slate-100">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Confidence Intervals</h4>
                <div className="space-y-3">
                    {result.forecast.map((f, i) => (
                        <div key={i} className="flex justify-between items-center text-sm">
                            <span className="text-slate-600 font-medium">{f.period}</span>
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                                f.confidence === 'High' ? 'bg-emerald-100 text-emerald-700' :
                                f.confidence === 'Medium' ? 'bg-amber-100 text-amber-700' :
                                'bg-red-100 text-red-700'
                            }`}>{f.confidence}</span>
                        </div>
                    ))}
                </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Forecasting;

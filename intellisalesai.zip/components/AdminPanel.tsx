
import React, { useEffect, useState } from 'react';
import { Shield, Users, Clock, Search, Trash2, Activity, Terminal, ExternalLink, Navigation, Link as LinkIcon, Database } from 'lucide-react';
import { getActivityLog, clearActivityLog } from '../services/activityService';
import { UserActivity } from '../types';

const ActivityIcon = ({ type }: { type: UserActivity['type'] }) => {
  switch (type) {
    case 'login': return <Users className="w-4 h-4 text-emerald-500" />;
    case 'query': return <Search className="w-4 h-4 text-indigo-500" />;
    case 'navigation': return <Navigation className="w-4 h-4 text-slate-400" />;
    default: return <Activity className="w-4 h-4 text-slate-400" />;
  }
};

const AdminPanel: React.FC = () => {
  const [activities, setActivities] = useState<UserActivity[]>([]);
  const [filter, setFilter] = useState<UserActivity['type'] | 'all'>('all');

  useEffect(() => {
    setActivities(getActivityLog());
    const interval = setInterval(() => {
      setActivities(getActivityLog());
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleClear = () => {
    if (confirm("Clear all audit logs?")) {
      clearActivityLog();
      setActivities([]);
    }
  };

  const filtered = filter === 'all' ? activities : activities.filter(a => a.type === filter);
  const queries = activities.filter(a => a.type === 'query');

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-slate-900 text-white p-8 rounded-3xl shadow-2xl border border-slate-800 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <Shield className="w-40 h-40" />
        </div>
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-indigo-500/20 rounded-2xl border border-indigo-500/30">
              <Shield className="w-6 h-6 text-indigo-400" />
            </div>
            <div>
              <h2 className="text-2xl font-black tracking-tight uppercase">System Governance</h2>
              <p className="text-indigo-300/60 text-xs font-bold tracking-widest uppercase">Search History & User Telemetry</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-black uppercase text-indigo-300">Total Activities</span>
                <Activity className="w-4 h-4 text-indigo-400" />
              </div>
              <div className="text-3xl font-black">{activities.length}</div>
            </div>
            <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-black uppercase text-emerald-300">Unique Users</span>
                <Users className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-3xl font-black">{new Set(activities.map(a => a.userId)).size}</div>
            </div>
            <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-black uppercase text-amber-300">Intelligence Queries</span>
                <Terminal className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-3xl font-black">{queries.length}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Activity Stream */}
        <div className="lg:col-span-2 bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex justify-between items-center">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest">Audit Trail</h3>
            <div className="flex gap-2">
                <select 
                    value={filter} 
                    onChange={(e) => setFilter(e.target.value as any)}
                    className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-[10px] font-black uppercase outline-none"
                >
                    <option value="all">All Events</option>
                    <option value="login">Logins</option>
                    <option value="query">Queries</option>
                    <option value="navigation">Navigation</option>
                </select>
                <button onClick={handleClear} className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                    <Trash2 className="w-4 h-4" />
                </button>
            </div>
          </div>
          <div className="max-h-[600px] overflow-y-auto custom-scrollbar">
            {filtered.length > 0 ? (
                <div className="divide-y divide-slate-50">
                    {filtered.map(a => (
                        <div key={a.id} className="p-4 hover:bg-slate-50/50 transition-colors flex gap-4">
                            <div className="mt-1"><ActivityIcon type={a.type} /></div>
                            <div className="flex-1">
                                <div className="flex justify-between items-start mb-1">
                                    <span className="text-xs font-black text-slate-800">{a.userName}</span>
                                    <span className="text-[10px] font-bold text-slate-400">{new Date(a.timestamp).toLocaleTimeString()}</span>
                                </div>
                                <p className="text-xs text-slate-600 leading-relaxed bg-slate-100/50 p-2 rounded-lg border border-slate-200/50">
                                    {a.action}
                                </p>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="p-12 text-center text-slate-400 text-xs italic">No activity logs found.</div>
            )}
          </div>
        </div>

        {/* Search History Recap */}
        <div className="space-y-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
                <div className="flex items-center gap-2 mb-6">
                    <Database className="w-4 h-4 text-indigo-500" />
                    <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest">Search History</h3>
                </div>
                <div className="space-y-3">
                    {queries.slice(0, 10).map((q, i) => (
                        <div key={i} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex flex-col gap-1">
                            <div className="flex justify-between">
                                <span className="text-[9px] font-black text-indigo-500 uppercase">{q.userName}</span>
                                <Clock className="w-3 h-3 text-slate-300" />
                            </div>
                            <p className="text-[11px] font-bold text-slate-700 line-clamp-2 italic">"{q.action.replace('Strategy Advisor: ', '').replace('Competitive Intelligence: ', '')}"</p>
                        </div>
                    ))}
                    {queries.length === 0 && <p className="text-xs text-slate-400 italic">No queries logged yet.</p>}
                </div>
            </div>

            <div className="bg-indigo-600 p-6 rounded-3xl text-white shadow-xl">
                <h4 className="text-[10px] font-black uppercase tracking-widest text-indigo-200 mb-4">Security Notice</h4>
                <p className="text-xs font-medium leading-relaxed opacity-80 mb-4">
                    All user queries and navigational paths are monitored for quality assurance and compliance audits.
                </p>
                <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest bg-white/10 p-2 rounded-lg">
                    <Shield className="w-3 h-3" />
                    Encryption Active
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;

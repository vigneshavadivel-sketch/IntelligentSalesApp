
import React, { useState } from 'react';
import { Lock, Mail, Activity, Info, ArrowRight, User as UserIcon, ShieldCheck, UserCircle, Loader2 } from 'lucide-react';
import { User } from '../types';

interface LoginProps {
  onLogin: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'Admin' | 'User'>('Admin');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoading(true);
    
    setTimeout(() => {
      setLoading(false);
      const user: User = {
        id: Math.random().toString(36).substr(2, 9),
        name: name || (role === 'Admin' ? 'Alexander Pierce' : 'Sarah Jenkins'),
        email: email || (role === 'Admin' ? 'admin@intellisales.ai' : 'sarah.j@intellisales.ai'),
        role: role === 'Admin' ? 'Senior Strategist' : 'Market Analyst',
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${name || (role === 'Admin' ? 'admin' : 'user')}`,
        roleType: role
      };
      onLogin(user);
    }, 1200);
  };

  const fillDemoCredentials = () => {
    if (role === 'Admin') {
      setName('Alexander Pierce');
      setEmail('admin@intellisales.ai');
    } else {
      setName('Sarah Jenkins');
      setEmail('sarah.j@intellisales.ai');
    }
    setPassword('admin123');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-900 via-slate-900 to-black p-4">
      <div className="bg-white/10 backdrop-blur-xl p-8 rounded-3xl shadow-2xl w-full max-w-md border border-white/10 relative overflow-hidden">
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-indigo-500/20 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-purple-500/20 rounded-full blur-3xl"></div>

        <div className="flex flex-col items-center mb-6 relative z-10">
          <div className="bg-gradient-to-tr from-indigo-500 to-purple-500 p-4 rounded-2xl mb-4 shadow-xl">
            <Activity className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-black text-white tracking-tight">IntelliSales AI</h1>
          <p className="text-indigo-200/70 mt-1 font-bold text-[10px] uppercase tracking-widest">Enterprise Intelligence</p>
        </div>

        <div className="relative z-10 mb-8 p-1.5 bg-slate-800/60 rounded-2xl border border-white/5 flex gap-1">
          <button type="button" onClick={() => setRole('Admin')} className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${role === 'Admin' ? 'bg-indigo-600 text-white shadow-lg' : 'text-indigo-300/50'}`}>
            <ShieldCheck className="w-4 h-4" /> Admin
          </button>
          <button type="button" onClick={() => setRole('User')} className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${role === 'User' ? 'bg-indigo-600 text-white shadow-lg' : 'text-indigo-300/50'}`}>
            <UserCircle className="w-4 h-4" /> User
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 relative z-10">
          <div className="space-y-1">
            <label className="text-[10px] font-black uppercase tracking-widest text-indigo-300/50 ml-1">Identity</label>
            <div className="relative group">
              <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-indigo-300/30 w-5 h-5" />
              <input type="text" value={name} onChange={(e) => setName(e.target.value)} className="w-full pl-12 pr-4 py-3 bg-slate-800/40 border border-white/10 rounded-2xl text-white outline-none focus:ring-2 focus:ring-indigo-500" placeholder="Name" required />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-black uppercase tracking-widest text-indigo-300/50 ml-1">Email</label>
            <div className="relative group">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-indigo-300/30 w-5 h-5" />
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full pl-12 pr-4 py-3 bg-slate-800/40 border border-white/10 rounded-2xl text-white outline-none focus:ring-2 focus:ring-indigo-500" placeholder="Email" required />
            </div>
          </div>
          
          <div className="space-y-1">
            <label className="text-[10px] font-black uppercase tracking-widest text-indigo-300/50 ml-1">Access Key</label>
            <div className="relative group">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-indigo-300/30 w-5 h-5" />
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full pl-12 pr-4 py-3 bg-slate-800/40 border border-white/10 rounded-2xl text-white outline-none focus:ring-2 focus:ring-indigo-500" placeholder="••••••••" required />
            </div>
          </div>

          <button type="submit" disabled={loading} className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black uppercase tracking-widest py-4 rounded-2xl transition-all shadow-xl flex items-center justify-center gap-3 active:scale-[0.98] disabled:opacity-70 mt-4">
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <>Access Console <ArrowRight className="w-4 h-4" /></>}
          </button>
        </form>

        <div onClick={fillDemoCredentials} className="mt-8 p-4 bg-indigo-500/10 border border-indigo-500/20 rounded-2xl cursor-pointer hover:bg-indigo-500/20 transition-all">
          <div className="flex items-start gap-3">
            <Info className="w-4 h-4 text-indigo-300 mt-0.5" />
            <div>
              <h4 className="text-[10px] font-black uppercase tracking-widest text-indigo-300 mb-1">Demo Access (Click to Fill)</h4>
              <p className="text-[11px] text-indigo-100/70 font-medium">Email: <span className="text-white">{role === 'Admin' ? 'admin@intellisales.ai' : 'sarah.j@intellisales.ai'}</span></p>
              <p className="text-[11px] text-indigo-100/70 font-medium">Password: <span className="text-white">admin123</span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;

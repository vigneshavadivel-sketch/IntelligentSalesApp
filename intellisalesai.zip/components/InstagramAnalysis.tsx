
import React, { useState } from 'react';
import { Instagram, Search, Loader2, TrendingUp, Target, Palette, Zap, Image as ImageIcon, Sparkles, BarChart3, ExternalLink, Link as LinkIcon } from 'lucide-react';
import { analyzeInstagramAccount } from '../services/geminiService';
import { InstagramAnalysisResult } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const InstagramAnalysis: React.FC = () => {
  const [handle, setHandle] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<InstagramAnalysisResult | null>(null);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!handle.trim()) return;

    setLoading(true);
    try {
      const data = await analyzeInstagramAccount(handle);
      setResult(data);
    } catch (error) {
      console.error(error);
      alert("Analysis failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Search Section */}
      <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
        <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-gradient-to-tr from-purple-500 to-pink-500 rounded-xl">
                <Instagram className="w-6 h-6 text-white" />
            </div>
            <div>
                <h2 className="text-2xl font-black text-slate-800 tracking-tight">Instagram Intelligence</h2>
                <p className="text-slate-500 text-sm font-medium">Predict social growth & audit competitor brand health based on profile handle.</p>
            </div>
        </div>

        <form onSubmit={handleAnalyze} className="grid grid-cols-1 md:grid-cols-12 gap-6 items-end">
            <div className="md:col-span-10">
                <label className="block text-xs font-black uppercase tracking-widest text-slate-400 mb-2">Profile Handle</label>
                <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">@</span>
                    <input
                        type="text"
                        value={handle}
                        onChange={(e) => setHandle(e.target.value)}
                        className="w-full pl-8 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:bg-white outline-none transition-all font-medium"
                        placeholder="competitor_handle"
                        required
                    />
                </div>
            </div>

            <div className="md:col-span-2">
                <button
                    type="submit"
                    disabled={loading || !handle}
                    className="w-full h-[52px] bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-black uppercase tracking-widest text-xs rounded-xl shadow-lg shadow-purple-200 transition-all flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
                >
                    {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
                    Analyze
                </button>
            </div>
        </form>
      </div>

      {result && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
            {/* Main Insights */}
            <div className="lg:col-span-2 space-y-6">
                <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-8 opacity-5">
                        <Instagram className="w-32 h-32" />
                    </div>
                    <div className="flex items-center justify-between mb-8">
                        <div>
                            <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight">Audit: @{result.handle}</h3>
                            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">AI-Powered Social Diagnosis</p>
                        </div>
                        <div className="text-right">
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Brand Health Score</span>
                            <div className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
                                {result.brandHealthScore}%
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                            <div className="flex items-center gap-2 mb-4">
                                <Palette className="w-4 h-4 text-purple-500" />
                                <h4 className="text-xs font-black uppercase tracking-widest text-slate-800">Visual Identity Audit</h4>
                            </div>
                            <p className="text-sm text-slate-600 leading-relaxed font-medium bg-slate-50 p-4 rounded-xl border border-slate-100">
                                {result.visualIdentityAudit}
                            </p>
                        </div>
                        <div>
                            <div className="flex items-center gap-2 mb-4">
                                <Target className="w-4 h-4 text-pink-500" />
                                <h4 className="text-xs font-black uppercase tracking-widest text-slate-800">Perceived Audience</h4>
                            </div>
                            <p className="text-sm text-slate-600 leading-relaxed font-medium bg-slate-50 p-4 rounded-xl border border-slate-100">
                                {result.perceivedAudience}
                            </p>
                        </div>
                    </div>
                    
                    <div className="mt-8">
                        <div className="flex items-center gap-2 mb-4">
                            <Zap className="w-4 h-4 text-amber-500" />
                            <h4 className="text-xs font-black uppercase tracking-widest text-slate-800">Strategic Pivot Recommendations</h4>
                        </div>
                        <div className="p-5 bg-indigo-900 text-white rounded-2xl shadow-xl relative group">
                            <p className="text-sm font-medium leading-relaxed italic">"{result.strategicPivot}"</p>
                        </div>
                    </div>
                </div>

                <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
                    <div className="flex items-center gap-2 mb-6">
                        <BarChart3 className="w-5 h-5 text-purple-600" />
                        <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight">6-Month Growth Projection</h3>
                    </div>
                    <div className="h-[300px] w-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={result.growthPredictions}>
                                <defs>
                                    <linearGradient id="colorFollow" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#a855f7" stopOpacity={0.3}/>
                                        <stop offset="95%" stopColor="#ec4899" stopOpacity={0}/>
                                    </linearGradient>
                                </defs>
                                <XAxis dataKey="month" stroke="#94a3b8" fontSize={10} fontWeight="bold" />
                                <YAxis stroke="#94a3b8" fontSize={10} fontWeight="bold" />
                                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                                <Tooltip 
                                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', fontWeight: 'bold' }}
                                />
                                <Area type="monotone" dataKey="followers" stroke="#a855f7" strokeWidth={4} fillOpacity={1} fill="url(#colorFollow)" />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>

            {/* Content Pillars & Hooks */}
            <div className="space-y-6">
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <h4 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-4">Core Content Themes</h4>
                    <div className="space-y-3">
                        {result.contentThemes.map((theme, i) => (
                            <div key={i} className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
                                <div className="w-2 h-2 rounded-full bg-purple-500 shadow-sm shadow-purple-500/50"></div>
                                <span className="text-sm font-bold text-slate-700">{theme}</span>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="bg-gradient-to-br from-purple-600 to-pink-600 p-8 rounded-2xl shadow-xl shadow-purple-200 text-white">
                    <div className="flex items-center gap-2 mb-6">
                        <Sparkles className="w-5 h-5" />
                        <h4 className="text-sm font-black uppercase tracking-widest">Conversion Hooks</h4>
                    </div>
                    <div className="space-y-4">
                        {result.engagementHooks.map((hook, i) => (
                            <div key={i} className="p-4 bg-white/10 backdrop-blur-md rounded-xl border border-white/10 hover:bg-white/20 transition-all cursor-default group">
                                <div className="flex gap-3">
                                    <span className="text-[10px] font-black opacity-40 group-hover:opacity-100 transition-opacity">0{i+1}</span>
                                    <p className="text-xs font-bold leading-relaxed">{hook}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="p-6 bg-slate-900 rounded-2xl border border-slate-800">
                    <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Live Predictive Status</span>
                        <div className="flex gap-1">
                            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                        </div>
                    </div>
                    <p className="text-xs text-slate-400 font-medium leading-relaxed">
                        Predictions updated based on {result.handle}'s current trend-cycle volatility.
                    </p>
                </div>

                {/* Guideline: Extract URLs from groundingChunks and list them */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                    <div className="flex items-center gap-3 mb-6">
                        <LinkIcon className="w-5 h-5 text-slate-400" />
                        <h3 className="text-sm font-black text-slate-800 uppercase tracking-tight">Intelligence Sources</h3>
                    </div>
                    <div className="space-y-3 max-h-[200px] overflow-y-auto pr-1">
                        {result.sources && result.sources.length > 0 ? (
                            result.sources.map((source, i) => (
                                <a 
                                    key={i} 
                                    href={source.uri} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="block p-3 bg-slate-50 border border-slate-100 rounded-lg hover:border-purple-300 transition-colors group"
                                >
                                    <div className="flex items-center justify-between gap-2">
                                        <span className="text-[10px] font-bold text-slate-700 truncate">{source.title}</span>
                                        <ExternalLink className="w-3 h-3 text-slate-400 group-hover:text-purple-500 shrink-0" />
                                    </div>
                                </a>
                            ))
                        ) : (
                            <p className="text-[10px] text-slate-400 italic font-bold">No web citations found for this analysis.</p>
                        )}
                    </div>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default InstagramAnalysis;

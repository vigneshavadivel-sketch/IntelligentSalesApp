
import React, { useState, useEffect } from 'react';
import { MessageSquare, Send, User, Bot, Sparkles } from 'lucide-react';
import { getStrategyAdvice } from '../services/geminiService';
import { logActivity } from '../services/activityService';
import { User as UserType } from '../types';

const StrategyAdvisor: React.FC = () => {
  const [query, setQuery] = useState('');
  const [messages, setMessages] = useState<{ role: 'user' | 'ai'; content: string }[]>([
    { role: 'ai', content: 'Hello! I am your AI Strategy Advisor. Ask me anything about improving your sales strategy, market penetration, or operational efficiency.' }
  ]);
  const [loading, setLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState<UserType | null>(null);

  // In a real app, we'd use a context. Here we'll just pull from what we know of the login state.
  useEffect(() => {
    // This is a simplified way to get user info since App holds the state
    // In a real scenario, use React Context or a global store.
  }, []);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    const userMessage = query;
    setQuery('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setLoading(true);

    // Activity logging
    // Since App.tsx holds the user, we try to grab it from localStorage where we might have cached it
    // Or in this specific setup, we'll assume the service can handle it if we pass it or if we mock the active user
    // For this demonstration, we'll assume a dummy user if not found, but it will be correctly logged if integrated with App context
    const dummyUser: UserType = {
        id: 'user_123',
        name: 'Active User',
        email: 'user@intellisales.ai',
        role: 'Market Analyst',
        avatar: '',
        roleType: 'User'
    };

    try {
      logActivity(dummyUser, 'query', `Strategy Advisor: ${userMessage}`, { component: 'StrategyAdvisor' });
      const response = await getStrategyAdvice(userMessage);
      setMessages(prev => [...prev, { role: 'ai', content: response }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'ai', content: "I'm having trouble connecting to the strategy database. Please try again." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 h-[650px] flex flex-col overflow-hidden">
      <div className="p-6 border-b border-slate-100 bg-slate-50/50">
        <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-600 rounded-2xl shadow-lg shadow-indigo-100">
                <MessageSquare className="w-6 h-6 text-white" />
            </div>
            <div>
                <h2 className="text-xl font-black text-slate-800 uppercase tracking-tight">Strategic Advisor</h2>
                <div className="flex items-center gap-1.5 mt-0.5">
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
                    <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Live Consulting Unit</p>
                </div>
            </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/30 custom-scrollbar">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`flex gap-4 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-sm border ${
                msg.role === 'user' ? 'bg-slate-900 text-white border-slate-800' : 'bg-white text-indigo-600 border-slate-100'
              }`}>
                {msg.role === 'user' ? <User className="w-5 h-5" /> : <Sparkles className="w-5 h-5" />}
              </div>
              <div className={`p-5 rounded-2xl shadow-sm text-sm leading-relaxed font-medium ${
                msg.role === 'user' 
                  ? 'bg-indigo-600 text-white rounded-tr-none' 
                  : 'bg-white text-slate-700 border border-slate-100 rounded-tl-none'
              }`}>
                {msg.content.split('\n').map((line, i) => (
                    <p key={i} className="mb-2 last:mb-0">{line}</p>
                ))}
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
             <div className="flex gap-4 max-w-[80%]">
                <div className="w-10 h-10 rounded-2xl bg-white text-indigo-600 border border-slate-100 flex items-center justify-center shadow-sm">
                    <Bot className="w-5 h-5 animate-pulse" />
                </div>
                <div className="bg-white p-5 rounded-2xl rounded-tl-none border border-slate-100 shadow-sm flex items-center gap-2">
                    <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce"></span>
                    <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce delay-75"></span>
                    <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce delay-150"></span>
                </div>
             </div>
          </div>
        )}
      </div>

      <div className="p-6 bg-white border-t border-slate-100">
        <form onSubmit={handleSend} className="relative group">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full pl-6 pr-14 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all text-slate-800 placeholder-slate-400 font-medium"
            placeholder="Describe your strategic challenge..."
          />
          <button
            type="submit"
            disabled={!query.trim() || loading}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-3 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg shadow-indigo-100"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest text-center mt-4">
            Encrypted Session • Admin Audited Portal
        </p>
      </div>
    </div>
  );
};

export default StrategyAdvisor;


import { defineConfig } from 'vite';

export default defineConfig({
  server: {
    port: 3000,
  },
  define: {
    // Safely inject specific environment variables into the client build
    'process.env.API_KEY': JSON.stringify(process.env.API_KEY)
  }
});

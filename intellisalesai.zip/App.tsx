
import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  TrendingUp, 
  Camera, 
  Target, 
  Lightbulb, 
  LogOut,
  Menu,
  X,
  Instagram,
  User as UserIcon,
  ChevronDown,
  ShieldAlert
} from 'lucide-react';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import Forecasting from './components/Forecasting';
import ProductAnalysis from './components/ProductAnalysis';
import CompetitorAnalysis from './components/CompetitorAnalysis';
import InstagramAnalysis from './components/InstagramAnalysis';
import StrategyAdvisor from './components/StrategyAdvisor';
import AdminPanel from './components/AdminPanel';
import { View, NavItem, ForecastResult, User } from './types';
import { logActivity } from './services/activityService';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [hasUploadedData, setHasUploadedData] = useState(false);
  const [forecastResult, setForecastResult] = useState<ForecastResult | null>(null);
  const [currentView, setCurrentView] = useState<View>('forecast');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);

  // Auto-switch to dashboard if data is uploaded while on forecast page
  useEffect(() => {
    if (hasUploadedData && currentView === 'forecast') {
      const timer = setTimeout(() => setCurrentView('dashboard'), 1500);
      return () => clearTimeout(timer);
    }
  }, [hasUploadedData]);

  // Log navigation
  useEffect(() => {
    if (user) {
      logActivity(user, 'navigation', `Switched view to ${currentView}`);
    }
  }, [currentView, user]);

  const navItems: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'forecast', label: 'Sales Forecasting', icon: TrendingUp },
    { id: 'product', label: 'Product Analysis', icon: Camera },
    { id: 'competitor', label: 'Competitor Spy', icon: Target },
    { id: 'social', label: 'Instagram Analysis', icon: Instagram },
    { id: 'strategy', label: 'Strategy Advisor', icon: Lightbulb },
    { id: 'admin-panel', label: 'Admin Panel', icon: ShieldAlert },
  ];

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    setIsAuthenticated(true);
    sessionStorage.setItem('session_start', Date.now().toString());
    logActivity(loggedInUser, 'login', `User ${loggedInUser.name} logged in from portal`);
    if (loggedInUser.roleType === 'Admin') {
      setCurrentView('admin-panel');
    }
  };

  const handleLogout = () => {
    if (user) logActivity(user, 'navigation', `User ${user.name} logged out`);
    setIsAuthenticated(false);
    setUser(null);
    setHasUploadedData(false);
    setForecastResult(null);
    setCurrentView('forecast');
    setIsProfileDropdownOpen(false);
    sessionStorage.removeItem('session_start');
  };

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard': return (
        <Dashboard 
          hasData={hasUploadedData} 
          forecastResult={forecastResult}
          onNavigateToForecast={() => setCurrentView('forecast')} 
        />
      );
      case 'forecast': return (
        <Forecasting 
          onDataUploaded={(data) => {
            setHasUploadedData(true);
            setForecastResult(data);
          }} 
          initialResult={forecastResult}
        />
      );
      case 'product': return <ProductAnalysis />;
      case 'competitor': return <CompetitorAnalysis />;
      case 'social': return <InstagramAnalysis />;
      case 'strategy': return <StrategyAdvisor />;
      case 'admin-panel': return <AdminPanel />;
      default: return (
        <Forecasting 
          onDataUploaded={(data) => {
            setHasUploadedData(true);
            setForecastResult(data);
          }} 
          initialResult={forecastResult}
        />
      );
    }
  };

  // Filter navigation items based on data upload status and permissions
  const visibleNavItems = navItems.filter(item => {
    if (item.id === 'dashboard') return hasUploadedData;
    if (item.id === 'admin-panel') return user?.roleType === 'Admin';
    return true;
  });

  return (
    <div className="min-h-screen bg-slate-50 flex font-sans text-slate-900">
      {/* Sidebar - Desktop */}
      <aside className="hidden lg:flex flex-col w-72 bg-slate-900 text-white fixed h-full z-20 transition-all duration-300">
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center gap-3">
             <div className="w-8 h-8 bg-gradient-to-tr from-indigo-500 to-purple-500 rounded-lg flex items-center justify-center">
                <span className="font-bold text-lg">I</span>
             </div>
             <h1 className="text-xl font-bold tracking-tight">IntelliSales AI</h1>
          </div>
        </div>
        
        <nav className="flex-1 p-4 space-y-1.5 overflow-y-auto mt-4">
          {visibleNavItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id)}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-200 ${
                  currentView === item.id 
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/50' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </div>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-800">
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:bg-red-500/10 hover:text-red-400 transition-all"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Mobile Sidebar Overlay */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="fixed inset-0 bg-black/50" onClick={() => setIsMobileMenuOpen(false)}></div>
          <aside className="fixed inset-y-0 left-0 w-64 bg-slate-900 text-white flex flex-col z-50">
            <div className="p-6 border-b border-slate-800 flex justify-between items-center">
                <span className="font-bold text-lg">IntelliSales AI</span>
                <button onClick={() => setIsMobileMenuOpen(false)}>
                    <X className="w-6 h-6 text-slate-400" />
                </button>
            </div>
            <nav className="flex-1 p-4 space-y-2">
                {visibleNavItems.map((item) => {
                    const Icon = item.icon;
                    return (
                    <button
                        key={item.id}
                        onClick={() => {
                            setCurrentView(item.id);
                            setIsMobileMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                        currentView === item.id 
                            ? 'bg-indigo-600 text-white' 
                            : 'text-slate-400 hover:bg-slate-800'
                        }`}
                    >
                        <Icon className="w-5 h-5" />
                        <span className="font-medium">{item.label}</span>
                    </button>
                    );
                })}
            </nav>
            <div className="p-4 border-t border-slate-800">
              <button 
                onClick={handleLogout}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:text-red-400"
              >
                <LogOut className="w-5 h-5" />
                <span>Sign Out</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 lg:ml-72 flex flex-col min-h-screen transition-all duration-300">
        <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-slate-200 px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-4">
                <button 
                    onClick={() => setIsMobileMenuOpen(true)}
                    className="lg:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                    <Menu className="w-6 h-6" />
                </button>
                <h2 className="text-xl font-bold text-slate-800">
                    {navItems.find(n => n.id === currentView)?.label}
                </h2>
            </div>
            
            <div className="flex items-center gap-4 relative">
                <div className="hidden md:flex flex-col items-end">
                    <span className="text-sm font-bold text-slate-700">{user?.name}</span>
                    <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest">{user?.role}</span>
                </div>
                
                <div className="relative">
                  <button 
                    onClick={() => setIsProfileDropdownOpen(!isProfileDropdownOpen)}
                    className="flex items-center gap-2 p-1 rounded-full hover:bg-slate-100 transition-all border border-transparent hover:border-slate-200"
                  >
                    <div className="w-10 h-10 rounded-full bg-slate-200 border-2 border-white shadow-sm overflow-hidden">
                        <img src={user?.avatar} alt="Profile" className="w-full h-full object-cover" />
                    </div>
                    <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isProfileDropdownOpen ? 'rotate-180' : ''}`} />
                  </button>

                  {isProfileDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-2xl border border-slate-100 py-2 animate-in fade-in slide-in-from-top-2 z-50">
                      <div className="px-4 py-3 border-b border-slate-50">
                        <p className="text-xs font-black uppercase tracking-widest text-slate-400 mb-1">Signed in as</p>
                        <p className="text-sm font-bold text-slate-800 truncate">{user?.email}</p>
                      </div>
                      <div className="p-2">
                        <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-600 hover:bg-slate-50 transition-all text-sm font-medium">
                          <UserIcon className="w-4 h-4" />
                          View Profile
                        </button>
                        <button 
                          onClick={handleLogout}
                          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-red-600 hover:bg-red-50 transition-all text-sm font-medium"
                        >
                          <LogOut className="w-4 h-4" />
                          Sign Out
                        </button>
                      </div>
                    </div>
                  )}
                </div>
            </div>
        </header>

        <div className="p-6 md:p-8 max-w-7xl mx-auto w-full">
            {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default App;

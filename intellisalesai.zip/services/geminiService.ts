import { GoogleGenAI, Type } from "@google/genai";

// Initialize AI with the standard environment key
// Guideline: Use the named parameter { apiKey: ... }
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

/**
 * ML Sales Forecasting from CSV Data
 * Performs time-series analysis and regression forecasting.
 */
export const analyzeDataset = async (csvData: string): Promise<any> => {
  try {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `You are an expert ML Data Scientist. Perform a complex time-series regression and sales forecast on the provided CSV data. 
      Analyze seasonality, growth velocity, and potential outliers. 
      Predict exactly the next 3 periods (e.g., months) with statistical confidence levels.
      Provide 3 high-level strategic ML-driven insights for executive reporting.
      
      Dataset:
      ${csvData}
      `,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            forecast: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  period: { type: Type.STRING },
                  predictedSales: { type: Type.NUMBER },
                  confidence: { type: Type.STRING, description: "High, Medium, or Low based on R-squared variance" }
                },
                required: ["period", "predictedSales", "confidence"]
              }
            },
            insights: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["forecast", "insights"]
        }
      }
    });
    
    // Guideline: Use .text property directly (it's a getter, not a method)
    const jsonStr = response.text.trim();
    return jsonStr ? JSON.parse(jsonStr) : null;
  } catch (error) {
    console.error("ML Dataset analysis failed", error);
    throw error;
  }
};

/**
 * Computer Vision Product Intelligence
 * Detects market demographic and category using visual feature extraction.
 */
export const analyzeProductImage = async (base64Image: string, reviews?: string): Promise<any> => {
    try {
        const ai = getAI();
        let promptText = `Perform a Computer Vision based market analysis of this product. 
        Extract visual features to determine category, primary demographic, and estimated price point in INR. 
        Calculate 'Sales Potential' by analyzing the trend velocity of similar visual styles in the 2024-2025 market.`;
        
        if (reviews) promptText += `\n\nCross-reference visual features with this customer sentiment data: ${reviews}`;

        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: {
                parts: [
                    { inlineData: { mimeType: 'image/jpeg', data: base64Image } },
                    { text: promptText }
                ]
            },
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        category: { type: Type.STRING },
                        demographic: { type: Type.STRING },
                        pricePointEstimate: { type: Type.STRING },
                        salesPotential: { type: Type.STRING },
                        demandAnalysis: {
                            type: Type.OBJECT,
                            properties: {
                                rating: { type: Type.STRING },
                                score: { type: Type.NUMBER },
                                trendVelocity: { type: Type.STRING },
                                marketSaturation: { type: Type.STRING },
                                explanation: { type: Type.STRING }
                            }
                        },
                        forecast: {
                          type: Type.ARRAY,
                          items: {
                            type: Type.OBJECT,
                            properties: {
                              month: { type: Type.STRING },
                              predictedSales: { type: Type.NUMBER }
                            }
                          }
                        },
                        reasoning: { type: Type.ARRAY, items: { type: Type.STRING } },
                        customerSentiment: { type: Type.STRING },
                        topReviewThemes: { type: Type.ARRAY, items: { type: Type.STRING } },
                        representativeQuotes: { type: Type.ARRAY, items: { type: Type.STRING } }
                    }
                }
            }
        });

        const jsonStr = response.text.trim();
        return jsonStr ? JSON.parse(jsonStr) : null;
    } catch (error) {
        console.error("ML Vision analysis failed", error);
        throw error;
    }
}

/**
 * Social Media Growth Modeling
 */
export const analyzeInstagramAccount = async (handle: string): Promise<any> => {
    try {
        const ai = getAI();
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: `Execute a brand intelligence audit on @${handle}. Evaluate follower/engagement ratio health, content pillars, and project 6-month social growth based on current algorithmic trends.`,
            config: {
                tools: [{ googleSearch: {} }],
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        handle: { type: Type.STRING },
                        brandHealthScore: { type: Type.NUMBER },
                        perceivedAudience: { type: Type.STRING },
                        visualIdentityAudit: { type: Type.STRING },
                        contentThemes: { type: Type.ARRAY, items: { type: Type.STRING } },
                        growthPredictions: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    month: { type: Type.STRING },
                                    followers: { type: Type.NUMBER }
                                }
                            }
                        },
                        strategicPivot: { type: Type.STRING },
                        engagementHooks: { type: Type.ARRAY, items: { type: Type.STRING } }
                    }
                }
            }
        });

        const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
            title: chunk.web?.title || "Search Result",
            uri: chunk.web?.uri
        })).filter((s: any) => s.uri) || [];

        const jsonStr = response.text.trim();
        return jsonStr ? { ...JSON.parse(jsonStr), sources } : null;
    } catch (error) {
        console.error("Social Intelligence analysis failed", error);
        throw error;
    }
}

/**
 * Competitive Intelligence & Market Displacement
 */
export const compareCompetitors = async (ourCompany: string, competitorName: string, context: string): Promise<any> => {
    try {
        const ai = getAI();
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: `Conduct a deep competitive intelligence scan comparing "${ourCompany}" against "${competitorName}" in "${context}". Use grounding tools to find the latest market sentiment, pricing, and feature gaps. Return a displacement strategy and trap questions.`,
            config: {
                tools: [{ googleSearch: {} }],
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        ourCompany: {
                            type: Type.OBJECT,
                            properties: {
                                name: { type: Type.STRING },
                                swot: {
                                    type: Type.OBJECT,
                                    properties: {
                                        strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
                                        weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
                                        opportunities: { type: Type.ARRAY, items: { type: Type.STRING } },
                                        threats: { type: Type.ARRAY, items: { type: Type.STRING } }
                                    }
                                }
                            }
                        },
                        competitor: {
                            type: Type.OBJECT,
                            properties: {
                                name: { type: Type.STRING },
                                swot: {
                                    type: Type.OBJECT,
                                    properties: {
                                        strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
                                        weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
                                        opportunities: { type: Type.ARRAY, items: { type: Type.STRING } },
                                        threats: { type: Type.ARRAY, items: { type: Type.STRING } }
                                    }
                                }
                            }
                        },
                        winStrategy: { type: Type.ARRAY, items: { type: Type.STRING } },
                        trapQuestions: { type: Type.ARRAY, items: { type: Type.STRING } },
                        marketShareComparison: { type: Type.STRING }
                    }
                }
            }
        });

        const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
            title: chunk.web?.title || "Competitive Report",
            uri: chunk.web?.uri
        })).filter((s: any) => s.uri) || [];

        const jsonStr = response.text.trim();
        return jsonStr ? { ...JSON.parse(jsonStr), sources } : null;
    } catch (error) {
        console.error("Competitive Intelligence failed", error);
        throw error;
    }
}

/**
 * Strategic Advice Agent
 */
export const getStrategyAdvice = async (query: string): Promise<string> => {
    try {
        const ai = getAI();
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: `Act as a senior L3 BI Consultant. Provide a highly actionable, ML-driven strategic response for the following business query: "${query}"`
        });
        return response.text.trim() || "Strategy synthesis unavailable.";
    } catch (error) {
        console.error("Strategic Advice failed", error);
        throw error;
    }
}
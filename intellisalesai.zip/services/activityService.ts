
import { User, UserActivity } from '../types';

const ACTIVITY_KEY = 'intellisales_activity_log';

export const logActivity = (user: User, type: UserActivity['type'], action: string, metadata?: any) => {
  const activities: UserActivity[] = JSON.parse(localStorage.getItem(ACTIVITY_KEY) || '[]');
  
  const newActivity: UserActivity = {
    id: Math.random().toString(36).substr(2, 9),
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    type,
    action,
    timestamp: Date.now(),
    metadata
  };

  activities.unshift(newActivity);
  // Keep only last 200 activities
  localStorage.setItem(ACTIVITY_KEY, JSON.stringify(activities.slice(0, 200)));
};

export const getActivityLog = (): UserActivity[] => {
  return JSON.parse(localStorage.getItem(ACTIVITY_KEY) || '[]');
};

export const clearActivityLog = () => {
  localStorage.setItem(ACTIVITY_KEY, '[]');
};

export const getSessionDuration = (): string => {
  const start = sessionStorage.getItem('session_start');
  if (!start) return '0m';
  const diff = Date.now() - parseInt(start);
  const minutes = Math.floor(diff / 60000);
  return `${minutes}m`;
};
